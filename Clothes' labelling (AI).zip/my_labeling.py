__authors__ = 'TO_BE_FILLED'
__group__ = 'TO_BE_FILLED'

import time
import matplotlib.pyplot as plt
import numpy as np

from utils_data import read_dataset, read_extended_dataset, crop_images, visualize_retrieval ,Plot3DCloud, visualize_k_means
from Kmeans import get_colors, distance, KMeans
from KNN import *

if __name__ == '__main__':

    # Load all the images and GT
    train_imgs, train_class_labels, train_color_labels, test_imgs, test_class_labels, \
        test_color_labels = read_dataset(root_folder='./images/', gt_json='./images/gt.json')

    # List with all the existent classes
    classes = list(set(list(train_class_labels) + list(test_class_labels)))

    # Load extended ground truth
    imgs, class_labels, color_labels, upper, lower, background = read_extended_dataset()
    cropped_images = crop_images(imgs, upper, lower)



    # You can start coding your functions here
    """---------- TEST KMEANS ----------"""
    print("---------- TESTS KMEANS ----------")

    # Funció qualitativa Kmeans
    print("---Retrieval by color---")
    def Retrieval_by_color(image, labels, query):
        """
        Funió que realitza una cerca qualitativa d'imatges basada en els
        colors assignats per l'algorisme Kmeans.
        Args:
            image: Llista d'imatges
            labels: Llista d'etiquetes assignades a les imatges per l'algorisme Kmeans
            query: Colors que es volen cercar a les imatges (str o llista de str)

        Returns:
            Llista d'imatges que contenen els colors especificats de la llista
        """
        retrieved_img = []
        colors = []
        for i, img in enumerate(image):
            if all(color in labels[i] for color in query):
                retrieved_img.append(img)
                colors.append(labels[i])

        return retrieved_img,colors


    # Funcions Quantitativa 1: KMeans
    print("---Color accuracy---")
    def Get_color_accuracy(color_labels, GT_color_labels):
        correct = 0
        total_samples = len(color_labels)
        ok = []

        for pred_colors, GT_colors in zip(color_labels, GT_color_labels):
            if all(color in GT_colors for color in pred_colors):
                correct += 1
                ok.append(True)
            else:
                ok.append(False)

        if total_samples != 0:
            accuracy = correct / total_samples
        else:
            accuracy = 0
        return accuracy, ok


    print("---Funcions millora centroides---")
    def visualize_initial_centroids(centroids):
        """
        Visualiza los centroides inicializados.

        Args:
            centroids (numpy array): Array de centroides.
        """
        fig = plt.figure()

        if centroids.shape[1] == 3:  # Visualización en 3D si hay 3 dimensiones
            ax = fig.add_subplot(111, projection='3d')
            ax.scatter(centroids[:, 0], centroids[:, 1], centroids[:, 2], c='red', marker='o', s=100)
            ax.set_title('Centroides Inicializados (3D)')
            ax.set_xlabel('Dimensión 1')
            ax.set_ylabel('Dimensión 2')
            ax.set_zlabel('Dimensión 3')
        else:  # Visualización en 2D para cualquier otra cantidad de dimensiones
            plt.scatter(centroids[:, 0], centroids[:, 1], c='red', marker='o', s=100)
            plt.title('Centroides Inicializados (2D)')
            plt.xlabel('Dimensión 1')
            plt.ylabel('Dimensión 2')

        plt.show()


    def analysis_init_centroids(imgs, K, options, kMax):
        t1 = time.time()
        colors = []
        kms = []
        for input in imgs:
            img = input
            km = KMeans(img, K, options)
            # km.find_bestK(kMax)
            km.fit()
            color = get_colors(km.centroids)
            colors.append(color)
            kms.append(km)

            # Visualització del centroides incialitzat
            # Si no es vol veure la inicialització comentar
            visualize_initial_centroids(km.centroids)

        t2 = time.time() - t1
        print("Time:", t2, "s")

        return colors, kms

    '''
    colors, kms = analysis_init_centroids(cropped_images, 3, {'km_init': 'custom'}, 5)
    res, color = Retrieval_by_color(imgs, colors, ['Pink'])
    print("Total accuracy:", Get_color_accuracy(colors, color_labels)[0]*100,"%")
    # Get GT imgs and index
    index = []
    gt = []
    for ix, input in enumerate(imgs):
        for r in res:
            if np.array_equal(input, r):
                index.append(ix)
                gt.append(input)
                break

    # Get GT color labels
    gt_color = []
    for ix in range(len(index)):
        gt_color.append(color_labels[index[ix]])

    # Accuracy calculation
    accuracy, ok = Get_color_accuracy(color, gt_color)
    print("Accuracy:", accuracy * 100, "%")
    

    visualize_retrieval(res, 32, ok=ok)
    '''

    print("---Funcions millora Discriminant de Fischer---")
    def analysis_find_bestK(imgs, maxK, gt_colors):
        fischer_list = []
        intra_class_list = []

        temps_fischer = 0
        temps_intra_class = 0

        colors = []

        for input in imgs:
            km = KMeans(input, options={'km_init': 'first'})
            #Temps per intra-class
            t1 = time.time()
            km.find_bestK(maxK, opcio='intra-class')
            t2 = time.time() - t1
            temps_intra_class += t2
            intra_class_list.append(km.K)

            #Temps per fischer
            t1 = time.time()
            km.find_bestK(maxK, opcio='fischer')
            t2 = time.time() - t1
            temps_fischer += t2
            fischer_list.append(km.K)

            #Comprovar precisió nous clusters amb fischer
            km.fit()
            color = get_colors(km.centroids)
            colors.append(color)


        count = 0

        for i in range(len(fischer_list)):
            if fischer_list[i] == intra_class_list[i]:
                count += 1

        print("Temps amb discriminant de Fischer:", temps_fischer)
        print("Temps amb intra-class distance:", temps_intra_class)
        print("Igualtats en número de clusters utilitzant fischer o inta_class:", count, "/", len(fischer_list))
        print("Accuracy de colors amb fischer:", Get_color_accuracy(colors, gt_colors)[0] *100, '%')

        imatges_visualitzar, colores = Retrieval_by_color(imgs, colors, ['Yellow'])
        visualize_retrieval(imatges_visualitzar, 10)

    analysis_find_bestK(train_imgs, 10, train_color_labels)


    """# Get kmeans
    for i in range(len(kms)):
        fig = plt.figure()
        ax = Plot3DCloud(kms[i])
        plt.show(block=False)  # Show the plot without blocking the execution
        plt.pause(5)  # Pause briefly to allow user interaction
        if not plt.get_fignums():  # Check if all figure windows are closed
            break"""

    """---------- TEST KNN ----------"""
    print("\n---------- TEST KNN ----------")
    # Funció qualitativa

    print("---Retrieval by shape---")
    def Retrieval_by_shape(image, labels, query):
        """
        Funió que realitza una cerca qualitativa d'imatges basada en els
        colors assignats per l'algorisme Kmeans.
        Args:
            image: Llista d'imatges
            labels: Llista d'etiquetes assignades a les imatges per l'algorisme Kmeans
            query: Colors que es volen cercar a les imatges (str o llista de str)

        Returns:
            Llista d'imatges que contenen els colors especificats de la llista
        """

        retrieved_img = []

        for i, img in enumerate(image):
            if all(shape in labels[i] for shape in query):
                retrieved_img.append(img)

        return retrieved_img


    def compare_shapes(predicted_shapes, ground_truth_shapes):
        """
        Compare predicted shapes with ground-truth shapes.

        Args:
        - predicted_shapes (list): List of predicted shapes.
        - ground_truth_shapes (list): List of ground-truth shapes.

        Returns:
        - match_list (list): List of boolean values indicating whether each predicted shape matches the ground-truth shape.
        """
        match_list = []
        for predicted_shape, gt_shape in zip(predicted_shapes, ground_truth_shapes):
            # Compare if the predicted shape matches the ground-truth shape
            match = predicted_shape == gt_shape
            match_list.append(match)
        return match_list

    # Funcions Quantitatives
    print("---Shape accuracy---")
    def Get_shape_accuracy(predicted_labels, GT_labels):
        """
        Calcula el percentatge d'etiquetes correctes entre les prediccions i les etiquetes de referència (GT)
        Args:
            predicted_labels: (list) Llista d'etiquetes predicted pel KNN
            GT_labels: (list) Llista d'etiquetes de referència (GT)

        Returns:
            float: Percentatge d'etiquetes correctes.
        """

        # Comprovar que el número d'etiquetes predicted i de referència sigui el mateix
        if len(predicted_labels) != len(GT_labels):
            raise ValueError("Les dues llistes han de tenir el mateix número d'etiquetes")

        # Contar el número d'etiquetes correctes
        count = 0

        for i in range(len(predicted_labels)):
            if predicted_labels[i] == GT_labels[i]:
                count += 1

        # Calcular el percentatge d'etiquetes correctes
        accuracy = (count / len(predicted_labels)) * 100

        return accuracy

    #Accuracy pel knn
    def analysis_knn(imatges, shape_labels):

        knn = KNN(imatges, shape_labels)
        labels = knn.predict(imatges, 20)

        count = 0
        accuracy = Get_shape_accuracy(labels, shape_labels)

        print("Accuracy:", round(accuracy, 2), "%")


    #analysis_knn(train_imgs, train_class_labels)

    """---------- TEST KMEANS & KNN ----------"""
    print("---Retrieval combined---")
    # Funció qualitativa
    def Retrieval_combined(image, shape_label, color_label, shape_query, color_query):
        """
        Funió que realitza una cerca qualitativa d'imatges basada en els
            colors assignats per l'algorisme Kmeans.
            Args:
                image: Llista d'imatges
                shape_label: Llista d'etiquetes assignades a les imatges per l'algorisme KNN
                color_label: Llista d'etiquetes assignades a les imatges per l'algorisme Kmeans
                shape_query: Formes que es volen cerca a les imatges (str o llista de str)
                color_query: Colors que es volen cercar a les imatges (str o llista de str)

        Returns:
            Llista d'imatges que contenen la forma i colors especificats de la llista
            """

        retrieved_images = []

        for i, img in enumerate(image):
            if (all(color in color_label[i] for color in color_query) and
                    all(shape in shape_label[i] for shape in shape_query)):
                retrieved_images.append(img)

        return retrieved_images


    """res = Retrieval_combined(train_imgs, train_class_labels, train_color_labels, ['Flip Flops'], ['Yellow'])
    visualize_retrieval(res, 10)"""

    #PROVES PER L'ÚLTIMA MILLORA
    print("---Tests per la tercera millora---")
    def flip_image_vertically(image):
        return np.fliplr(image)

    flipped_train_imgs_vertical = [flip_image_vertically(img) for img in train_imgs]
    all_shape_labels = np.concatenate((train_class_labels, train_class_labels))
    totes_imgs = np.concatenate((train_imgs, flipped_train_imgs_vertical))

    def analysis_knn_doble_imatges(imatges, shape_labels):

        knn = KNN(imatges, shape_labels)
        labels = knn.predict(imatges, 20)

        print("long labels:", len(shape_labels), "long predicted:", len(labels))

        count = 0
        accuracy = Get_shape_accuracy(labels, shape_labels)

        print("Accuracy:", round(accuracy, 2), "%")


    #analysis_knn_doble_imatges(totes_imgs, all_shape_labels)

    '''
    res = Retrieval_combined(flipped_train_imgs_vertical, train_class_labels, train_color_labels, ['Flip Flops'],
                             ['Yellow'])
    visualize_retrieval(res, 10)

    res = Retrieval_combined(train_imgs, train_class_labels, train_color_labels, ['Flip Flops'], ['Yellow'])
    visualize_retrieval(res, 10)

    res = Retrieval_combined(totes_imgs, train_class_labels, train_color_labels, ['Flip Flops'], ['Yellow'])
    visualize_retrieval(res, 20)
    '''




#MODIFICACIONS KMEANS PER AL DISCRIMINANT DE FISCHER
# CAL UTILITZAR LA CLASSE KMEANS DE LA PRIMERA ENTREGA PER AL BON FUNCIONAMENT DE LA FUNCIÓ

def withinClassDistance(self):
    """
     returns the within class distance of the current clustering
    """
    wcd = 0

    for i in range(self.X.shape[0]):
        centroid = self.centroids[self.labels[i]]
        squared_distance = np.sum((self.X[i] - centroid) ** 2)
        wcd += squared_distance

    wcd /= self.X.shape[0]

    self.WCD = wcd

    return wcd


def betweenClassDIstance(self):
    """
    returns the between class distance of the current clustering
    """
    bcd = 0

    num_clusters = len(self.centroids)

    for i in range(num_clusters):
        centroid1 = self.centroids[i]

        for j in range(num_clusters):
            if i != j:
                centroid2 = self.centroids[j]
                squared_distance = np.sum((centroid1 - centroid2) ** 2)
                bcd += squared_distance

    bcd /= num_clusters
    return bcd


def find_bestK(self, max_K, opcio):
    """
    sets the best k analysing the results up to 'max_K' clusters
    """
    if opcio == 'fischer':
        best_K = max_K
        prev_dec = 100

        prev_fisc = np.inf

        for k in range(2, max_K):
            km = KMeans(self.X, K=k)
            km.fit()

            # Calcular WCD per a k clusters
            wcd = km.withinClassDistance()
            bcd = km.betweenClassDIstance()

            fischer = wcd / bcd

            if k > 2 and prev_fisc != 0:
                DEC = 100 * (prev_fisc - fischer) / prev_fisc

                if prev_dec >= 30 and DEC <= 30:
                    best_K = k - 1
                    prev_fisc = DEC
                    break

            prev_fisc = fischer

    if opcio == 'intra-class':
        best_K = max_K
        prev_dec = 100

        prev_wcd = np.inf

        for k in range(2, max_K):
            km = KMeans(self.X, K=k)
            km.fit()

            # Calcular WCD per a k clusters
            wcd = km.withinClassDistance()

            if k > 2 and prev_wcd != 0:
                DEC = 100 * (prev_wcd - wcd) / prev_wcd

                if prev_dec > 20 and DEC < 20:
                    best_K = k - 1
                    prev_dec = DEC
                    break

            prev_wcd = wcd

    self.K = best_K

#CANVIS A L'ARXIU KNN
    # CAL UTILITZAR L'ARXIU KNN PER AL BON FUNCIONAMENT
    def get_k_neighbours(self, test_data, k):
        """
        given a test_data matrix calculates de k nearest neighbours at each point (row) of test_data on self.neighbors
        :param test_data: array that has to be shaped to a NxD matrix (N points in a D dimensional space)
        :param k: the number of neighbors to look at
        :return: the matrix self.neighbors is created (NxK)
                 the ij-th entry is the j-th nearest train point to the i-th test point
        """
        #######################################################
        ##  YOU MUST REMOVE THE REST OF THE CODE OF THIS FUNCTION
        ##  AND CHANGE FOR YOUR OWN CODE
        #######################################################
        # Convertir los datos de entrenamiento a formato float si no lo están
        test_data = test_data.astype(float)
        # Redimensionar la matriz para que cada imagen sea un vector de características
        if test_data.ndim > 1:
            P = test_data.shape[0]  # Obtenim la primera dimensió
            other_dims_product = np.prod(test_data.shape[1:])  # Multipliquem totes les altres dimensions
            test_data = test_data.reshape(P, other_dims_product)

        # Calcular la distancia entre las muestras de test_data y train_data
        distances = cdist(test_data, self.train_data)

        # Ordenar las distancias de menor a mayor y guardar los índices
        sorted_indices = np.argsort(distances, axis=1)

        # Guardar las K etiquetas de las imágenes más cercanas para cada muestra del test
        self.neighbors = self.labels[sorted_indices[:, :k]]
