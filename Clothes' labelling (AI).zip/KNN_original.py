__authors__ = ['1671277', '1668991', '1667454']
__group__ = '282'

import numpy as np
import math
import operator
from scipy.spatial.distance import cdist


class KNN:
    def __init__(self, train_data, labels):
        self._init_train(train_data)
        self.labels = np.array(labels)
        #############################################################
        ##  THIS FUNCTION CAN BE MODIFIED FROM THIS POINT, if needed
        #############################################################

    def _init_train(self, train_data):
        """
        initializes the train data
        :param train_data: PxMxNx3 matrix corresponding to P color images
        :return: assigns the train set to the matrix self.train_data shaped as PxD (P points in a D dimensional space)
        """
        #######################################################
        ##  YOU MUST REMOVE THE REST OF THE CODE OF THIS FUNCTION
        ##  AND CHANGE FOR YOUR OWN CODE
        #######################################################
        # Convertir los datos de entrenamiento a formato float si no lo están
        self.train_data = train_data.astype(float)
        # Redimensionar la matriz para que cada imagen sea un vector de características
        self.train_data.shape = (train_data.shape[0], train_data.shape[1] * train_data.shape[2])

    def get_k_neighbours(self, test_data, k):
        """
        given a test_data matrix calculates de k nearest neighbours at each point (row) of test_data on self.neighbors
        :param test_data: array that has to be shaped to a NxD matrix (N points in a D dimensional space)
        :param k: the number of neighbors to look at
        :return: the matrix self.neighbors is created (NxK)
                 the ij-th entry is the j-th nearest train point to the i-th test point
        """
        #######################################################
        ##  YOU MUST REMOVE THE REST OF THE CODE OF THIS FUNCTION
        ##  AND CHANGE FOR YOUR OWN CODE
        #######################################################
        # Convertir los datos de entrenamiento a formato float si no lo están
        test_data = test_data.astype(float)
        # Redimensionar la matriz para que cada imagen sea un vector de características
        if test_data.ndim == 3:
            P, M, N = test_data.shape  # Obtenim la fila, columna i dimensió
            test_data = test_data.reshape(P, M * N)

        # Calcular la distancia entre las muestras de test_data y train_data
        distances = cdist(test_data, self.train_data)

        # Ordenar las distancias de menor a mayor y guardar los índices
        sorted_indices = np.argsort(distances, axis=1)

        # Guardar las K etiquetas de las imágenes más cercanas para cada muestra del test
        self.neighbors = self.labels[sorted_indices[:, :k]]

    def get_class(self):
        """
        Get the class by maximum voting
        :return: numpy array of Nx1 elements. For each of the rows in self.neighbors gets the most
        voted value (i.e. the class at which that row belongs)
        """
        # Initialize an empty array to store predicted class labels
        predicted_classes = np.empty(self.neighbors.shape[0], dtype=object)

        # Iterate over each row of self.neighbors
        for i, row in enumerate(self.neighbors):
            # Count occurrences of each class label in the current row using a dictionary
            label_counts = {}
            for label in row:
                if label in label_counts:
                    label_counts[label] += 1
                else:
                    label_counts[label] = 1

            # Find the most common class label
            most_common_label = max(label_counts, key=label_counts.get)

            # Assign the most common class label to the corresponding position in the output array
            predicted_classes[i] = most_common_label

        return predicted_classes

    def predict(self, test_data, k):
        """
        predicts the class at which each element in test_data belongs to
        :param test_data: array that has to be shaped to a NxD matrix (N points in a D dimensional space)
        :param k: the number of neighbors to look at
        :return: the output form get_class a Nx1 vector with the predicted shape for each test image
        """
        self.get_k_neighbours(test_data, k)
        return self.get_class()



