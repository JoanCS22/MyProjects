__authors__ = ['1671277', '1668991', '1667454']
__group__ = 'noneyet'

import numpy as np
import utils


class KMeans:

    def __init__(self, X, K=1, options=None):
        """
         Constructor of KMeans class
             Args:
                 K (int): Number of cluster
                 options (dict): dictionary with options
            """
        self.num_iter = 0
        self.K = K
        self._init_X(X)
        self._init_options(options)  # DICT options
        self._init_centroids()

    #############################################################
    ##  THIS FUNCTION CAN BE MODIFIED FROM THIS POINT, if needed
    #############################################################

    def _init_X(self, X):
        """Initialization of all pixels, sets X as an array of data in vector form (PxD)
            Args:
                X (list or np.array): list(matrix) of all pixel values
                    if matrix has more than 2 dimensions, the dimensionality of the sample space is the length of
                    the last dimension
        """
        # Comprovem que les dades de la matriu sigui tipus float
        if X.dtype != float:
            X = X.astype(float) # Canviem el tipus de dades de la matriu a tipus float

        # Comprovem si la dimenció de la matriu és 3
        if X.ndim == 3:
            F, C, D = X.shape # Obtenim la fila, columna i dimensió
            X = X.reshape(F * C, D) #

        self.X = X


    def _init_options(self, options):
        """
        Initialization of options in case some fields are left undefined
        Args:
            options (dict): dictionary with options
        """
        if options is None:
            options = {}
        if 'km_init' not in options:
            options['km_init'] = 'first'
        if 'verbose' not in options:
            options['verbose'] = False
        if 'tolerance' not in options:
            options['tolerance'] = 0
        if 'max_iter' not in options:
            options['max_iter'] = 1000
        if 'fitting' not in options:
            options['fitting'] = 'WCD'  # within class distance.

        # If your methods need any other parameter you can add it to the options dictionary
        self.options = options

        #############################################################
        ##  THIS FUNCTION CAN BE MODIFIED FROM THIS POINT, if needed
        #############################################################

    def _init_centroids(self):
        """
        Initialization of centroids
        """
        # Initialize centroids and old_centroids variables
        self.centroids = np.zeros((self.K, self.X.shape[1]))  # K x D matrix for centroids
        self.old_centroids = np.zeros((self.K, self.X.shape[1]))  # K x D matrix for old centroids

        # Comprovem l'opció d'inicialització triada
        if self.options['km_init'].lower() == 'first':
            # Obtenim els índex dels elements únics de les dades i els obtenim ordenats pel seu índex
            unique_indices = np.unique(self.X, axis=0, return_index=True)[1]
            unique_samples = [self.X[index] for index in sorted(unique_indices)]

            # Convertim la llista d'elements únics ordenats en un array NumPy
            unique_samples = np.array(unique_samples)

            # Comprovem si hi ha prou elements únics com a centroides
            if unique_samples.shape[0] >= self.K:
                self.centroids = unique_samples[:self.K] # Assignem els primers K elements com a centroids
                self.old_centroids = self.centroids.copy()

        elif self.options['km_init'].lower() == 'random':

            # Seleccionar índices aleatorios de los puntos de datos
            indices = np.random.choice(self.X.shape[0], self.K, replace=False)

            # Asignar los puntos correspondientes a los centroides
            self.centroids = self.X[indices]

            # Inicializar old_centroids correctamente
            self.old_centroids = np.zeros_like(self.centroids)

        elif self.options['km_init'].lower() == 'custom':
            # Calculate the diagonal of the feature space
            diagonal = np.sqrt(np.sum(np.square(self.X.max(axis=0) - self.X.min(axis=0))))

            # Calculate the step size for each dimension
            step_size = diagonal / self.K

            # Initialize centroids along the diagonal
            for i in range(self.K):
                # Set the coordinate for the i-th centroid
                self.centroids[i] = self.X.min(axis=0) + (step_size * i)

            # Initialize old_centroids
            self.old_centroids = self.centroids.copy()

    def get_labels(self):
        """
        Calculates the closest centroid of all points in X and assigns each point to the closest centroid
        """
        # Calcula la distància entre cada punt de X i cada centroid
        dist = distance(self.X, self.centroids)
        # Assignem cada punt al centroid més proper
        self.labels = np.argmin(dist, axis = 1)

    def get_centroids(self):
        """
        Calculates coordinates of centroids based on the coordinates of all the points assigned to the centroid
        """
        # Passa els centroids actuals a old_centroids
        self.old_centroids = self.centroids.copy()
        # Calcula els nous centroids
        new_centroids = np.zeros_like(self.centroids)
        for k in range(self.K):
            # Troba els punts que pertanyen al centroid k
            cluster_points = self.X[self.labels == k]
            # Calcula el nou centroid com el promig dels punts del clúster
            if len(cluster_points) > 0:
                new_centroids[k] = np.mean(cluster_points, axis=0)
        # Actualitza els centroids
        self.centroids = new_centroids

    def converges(self):
        """
        Checks if there is a difference between current and old centroids
        """
        # Comprova si hi ha una diferència entre els centroids actuals i els vells centroids
        diff = np.sum(np.abs(self.centroids - self.old_centroids))
        # Retorna True si la diferència és inferior a la tolerància definida a les opcions
        return diff <= self.options['tolerance']

    def fit(self):
        """
        Runs K-Means algorithm until it converges or until the number of iterations is smaller
        than the maximum number of iterations.
        """
        converges = False

        while not converges and self.num_iter < self.options['max_iter']:
            self.get_labels()
            self.get_centroids()
            self.num_iter += 1
            converges = self.converges()


    def withinClassDistance(self):
            """
             returns the within class distance of the current clustering
            """
            wcd = 0

            for i in range(self.X.shape[0]):
                centroid = self.centroids[self.labels[i]]
                squared_distance = np.sum((self.X[i] - centroid) ** 2)
                wcd += squared_distance

            wcd /= self.X.shape[0]

            self.WCD = wcd

            return wcd

    def betweenClassDIstance(self):
        """
        returns the between class distance of the current clustering
        """
        bcd = 0

        num_clusters = len(self.centroids)

        for i in range(num_clusters):
            centroid1 = self.centroids[i]

            for j in range(num_clusters):
                if i != j:
                    centroid2 = self.centroids[j]
                    squared_distance = np.sum((centroid1 - centroid2) ** 2)
                    bcd += squared_distance

        bcd /= num_clusters
        return bcd

    def find_bestK(self, max_K, opcio):
        """
        sets the best k analysing the results up to 'max_K' clusters
        """
        if opcio == 'fischer':
            best_K = max_K
            prev_dec = 100

            prev_fisc = np.inf

            for k in range(2, max_K):
                km = KMeans(self.X, K=k)
                km.fit()

                # Calcular WCD per a k clusters
                wcd = km.withinClassDistance()
                bcd = km.betweenClassDIstance()

                fischer = wcd / bcd

                if k > 2 and prev_fisc != 0:
                    DEC = 100 * (prev_fisc - fischer) / prev_fisc

                    if prev_dec >= 30 and DEC <= 30:
                        best_K = k - 1
                        prev_fisc = DEC
                        break

                prev_fisc = fischer

        if opcio == 'intra-class':
            best_K = max_K
            prev_dec = 100

            prev_wcd = np.inf

            for k in range(2, max_K):
                km = KMeans(self.X, K=k)
                km.fit()

                # Calcular WCD per a k clusters
                wcd = km.withinClassDistance()

                if k > 2 and prev_wcd != 0:
                    DEC = 100 * (prev_wcd - wcd) / prev_wcd

                    if prev_dec > 20 and DEC < 20:
                        best_K = k - 1
                        prev_dec = DEC
                        break

                prev_wcd = wcd

        self.K = best_K

def distance(X, C):
    """
    Calculates the distance between each pixel and each centroid
    Args:
        X (numpy array): PxD 1st set of data points (usually data points)
        C (numpy array): KxD 2nd set of data points (usually cluster centroids points)

    Returns:
        dist: PxK numpy array position ij is the distance between the
        i-th point of the first set an the j-th point of the second set
    """

    # Calculem la distància euclidiana entre cada punt de X i cada centroid de C
    #dist = np.sqrt(np.sum((X[:, np.newaxis] - C) ** 2, axis=2))
    dist = np.sum(np.abs(X[:, np.newaxis] - C), axis = 2)
    return dist


def get_colors(centroids):
    """
    for each row of the numpy matrix 'centroids' returns the color label following the 11 basic colors as a LIST
    Args:
        centroids (numpy array): KxD 1st set of data points (usually centroid points)

    Returns:
        labels: list of K labels corresponding to one of the 11 basic colors
    """

    color_probs = utils.get_color_prob(centroids)

    labels = []

    for row in color_probs:
        max_prob_index = row.argmax()
        color_label = utils.colors[max_prob_index]
        labels.append(color_label)

    return labels