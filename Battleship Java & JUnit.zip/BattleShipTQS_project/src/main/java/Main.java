import Model.Game;
import Controlador.GestorGame;


public class Main {

    public static void main(String[] args) {
        Game partida = new Game();
        GestorGame gestorPartida = new GestorGame(partida);
        gestorPartida.crearPartida();
        gestorPartida.partida();
    }
}