package Controlador;

import Model.Game;
import Model.Ship;
import Model.Coordenada;
import Vista.BoardPrinter;
import Vista.AccionsJugador;
/* 
 * Aquesta classe es dedica a cridar als diferents fitxer de la vista i el model 
 * per tal de controlar els moviments d'una partida
 */
public class GestorGame { 
	private Game partida;
	private BoardPrinter printer; // Objecte de la vista, encarregat d'imprimir per pantalla
	private AccionsJugador accions; // Objecte de la vista, s'encarrega de rebre els inputs dels usuaris

	public GestorGame(Game partida) {
		assert(partida != null); // Comprovem que no sigui null la partida pasada per paràmetre (no tindria sentit sino)
		this.partida = partida;
		
		accions = new AccionsJugador();
		printer = new BoardPrinter();
		
	}
	
	public Game getPartida() { return partida; } 
	public BoardPrinter getPrinter() { return printer; }
	public AccionsJugador getAccions() { return accions; }
	public void setAccions(AccionsJugador accions) {this.accions = accions; }

	public void crearPartida() {
		
		Ship[] ships = partida.getShips(); // Agafem tots els vaixell de la partida
		for(int i = 0; i < ships.length; i++) { // 1r inicialitzem els valors del tauler aleatori
			if(partida.getRandomPlayer().selectShipDirection() == 1) { //decidim si es posarà en horitzontal o vertical
				while(!partida.placeShip(ships[i], partida.getRandomPlayer().coordToPlaceShip(partida.getRandomPlayerBoard()), true , false)) {}
			}
			else {
				while(!partida.placeShip(ships[i], partida.getRandomPlayer().coordToPlaceShip(partida.getRandomPlayerBoard()), false , false)) {}
			}
		}
		// 2n inicialitzem els valors del tauler del jugador
		for(int i = 0; i < ships.length; i++) {
				int[] llista = accions.posicionarVaixells(ships[i]); // Recollim les dades de l'usuari
				if(llista[2] == 1) { // Decidim si es posarà en horitzontal o vertical
					partida.placeShip(ships[i], new Coordenada(llista[0], llista[1]), true, true); 
				}
				else {
					partida.placeShip(ships[i], new Coordenada(llista[0], llista[1]), false, true);
				}
		}
		// Finalment, cridem a la vista per imprimir per pantalla
		printer.printBoard(true, partida.getPlayerBoard());
		
	}

	public boolean dispararVaixellPlayer(boolean player) {
		int res = -1;
		while(res == -1) {
			if(player) { 
				Coordenada coordenada = accions.tornJugador(); // l'usuari introdueix les coordenades que vol atacar
				res = partida.dispararVaixell(coordenada, player);
				printer.printJugada(res); // S'imprimeix per pantalla la jugada
				
			}
			else {
				res = partida.dispararVaixell(partida.getRandomPlayer().coordToPlaceShip(partida.getRandomPlayerBoard()), player);
				printer.printJugada(res);
			}
				
		}
		
		if(player) { 
			printer.printBoard(false, partida.getRandomPlayerBoard()); // S'imprimeix el resultat per pantalla
		}
		return true;
	}
	
	public void partida() { // S'encarrega de jugar la partida
		boolean player = false;
		do {
			if (player == true) player = false; // Fa el canvi de torn entre l'usuari
			else player = true;
			
			dispararVaixellPlayer(player);
			
		} while(!partida.isOver(player)); // Comprova que la partida s'ha acabat
		
		printer.mostrarGuanyador(player); // Imprimeix per pantalla el resultat de la partida
	}
}