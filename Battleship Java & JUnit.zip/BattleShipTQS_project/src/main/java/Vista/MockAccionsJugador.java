package Vista;

import java.io.ByteArrayInputStream;

import Model.Ship;

public class MockAccionsJugador extends AccionsJugador {
	int indexPosicionar;
	public MockAccionsJugador() {
		indexPosicionar = 0;
	}
	
	public ByteArrayInputStream inputTornJugador(int index) {
		String simulatedInput;
        
		if(index == 0) 
			simulatedInput ="1\n2\n";
		else if(index == 1)
			simulatedInput ="a\n2\n4\n";
		else if(index == 2) 
			simulatedInput ="?\n5\n7\n";
		else if(index == 3) 
			simulatedInput ="9\n11\n3\n";
		else if(index == 4)
			simulatedInput ="-1\n7\n0\n";
		else if(index == 5)
			simulatedInput ="11\n7\n0\n";
		else if(index == 6)
			simulatedInput ="1\na\n0\n";
		else
			simulatedInput ="1\n-1\n0\n";
        ByteArrayInputStream input = new ByteArrayInputStream(simulatedInput.getBytes());
        return input;
	}
	
	public ByteArrayInputStream inputPosicionarVaixells(int index) {
		String simulatedInput;
        
		if(index == 0) 
			simulatedInput ="11\n1\n2\n0\n";
		else if(index == 1)
			simulatedInput ="a\n2\n4\na\n1\n";
		else if(index == 2) 
			simulatedInput ="?\n5\n-1\n7\n1\n";
		else if(index == 3) 
			simulatedInput ="9\n11\na\n3\n2\n0\n";
		else
			simulatedInput ="-1\n7\n0\n0\n";
		
        ByteArrayInputStream input = new ByteArrayInputStream(simulatedInput.getBytes());
        return input;
	}
	
	@Override
	public int[] posicionarVaixells(Ship ship) {
		int [] llista = new int[3];
		if(indexPosicionar == 0) {
			llista[0] = 0;
			llista[1] = 1;
			llista[2] = 1;
		}
		else if(indexPosicionar == 1) {
			llista[0] = 5;
			llista[1] = 2;
			llista[2] = 0;
		}
		else if(indexPosicionar == 2) {
			llista[0] = 4;
			llista[1] = 7;
			llista[2] = 1;
		}
		else if(indexPosicionar == 3) {
			llista[0] = 6;
			llista[1] = 8;
			llista[2] = 0;
		}
		else {
			llista[0] = 2;
			llista[1] = 4;
			llista[2] = 0;
		}
		
		incrementarIndexPosicionar();
		return llista;
		
	}
	
	private void incrementarIndexPosicionar() { indexPosicionar = indexPosicionar + 1; }
	
}