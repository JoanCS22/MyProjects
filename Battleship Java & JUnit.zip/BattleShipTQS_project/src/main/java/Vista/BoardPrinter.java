package Vista;
import Model.Board;
import Model.Cell;

public class BoardPrinter {

	public BoardPrinter() {}
	
	public void printJugada(int resultat) {
		if(resultat == 0) {
			System.out.println("Aigua!!");
		}
		else if(resultat > 0){
			System.out.println("S'ha tocat un vaixell!!");
			if(resultat == 2) {
				System.out.println("S'ha enfonsat el vaixell ");
			}
		}
		else {
			System.out.println("Aquesta casella no ès vàlida: fora del tauler o ja s'ha disparat abans.");
		}
	}
	
	//Mètode per printar el tauler de joc
		public void printBoard(boolean revealShips, Board board) {
		    System.out.print("  "); 
		    for (int col = 0; col < board.getNColumnes(); col++) {
		        System.out.print(col + " ");  // Imprimir números de columnes
		    }
		    System.out.println();

		    for (int row = 0; row < board.getNFiles(); row++) {
		        System.out.print(row + " ");  // Imprimir número de la fila
		        for (int col = 0; col < board.getNColumnes(); col++) {
		            Cell cell = board.getCasella(row, col);

		            if (cell.isGuessed()) 
		            {  // Si la cell ha sigut disparada
		                if (cell.getShip() != null) 
		                    System.out.print("X ");  // X per impacte de vaixell
		                else 
		                    System.out.print("O ");  // O per aigua
		                
		            } 
		            else 
		            {  // Cell no disparada
		                if (revealShips && (cell.getShip() != null)) 
		                    System.out.print("S ");  // Vaixell visible (per un mateix jugador)
		                else 
		                    System.out.print("~ ");  // Aigua no disparada
		                
		            }
		        }
		        System.out.println();
		    }
		}
		
		/*/
		No calen tests per la vista
		@Test
		void testPrintBoard()
		{
			System.out.println("Comença testing printBoard");
			System.out.println("Test sense vaixells, tot aigua");
			b1.printBoard(false); //Tot aigua
			System.out.println("Test sense vaixells encara");
			b1.printBoard(true); //Tot aigua (no s'han posat vaixells)
			
			
			b1.placeShip(s1, new Coordenada(0,0), true);
			System.out.println("Test amb un vaixell no visible");
			b1.printBoard(false); //Tot aigua
			System.out.println("Test amb un vaixell visible");
			b1.printBoard(true); //Primeres caselles amb S = Ship 
			
			
			b1.placeShip(s2, new Coordenada(2,0), false);
			b1.placeShip(s3, new Coordenada(4,5), false);
			b1.placeShip(s4, new Coordenada(0, 9), false);
			b1.placeShip(s5, new Coordenada(9, 8), true);
			
			System.out.println("Test amb tots els vaixells invisibles");
			b1.printBoard(false);
			System.out.println("Test amb tots els vaixells visibles");
			b1.printBoard(true);
			
			b1.dispararCasella(new Coordenada(0,0));
			b1.dispararCasella(new Coordenada(9,9));
			b1.dispararCasella(new Coordenada(9,0));
			
			System.out.println("Test amb dos vaixells tocats");
			b1.printBoard(false);
			b1.printBoard(true);
			
			for(int x = 0; x < b1.getNFiles(); x++)
			{
				for(int y = 0; y < b1.getNColumnes(); y++)
					b1.dispararCasella(new Coordenada(x,y));
			}
			
			System.out.println("Test amb totes les caselles disparades");
			b1.printBoard(false);
			b1.printBoard(true);
		}/*/
		
		public void mostrarGuanyador(boolean player) {
			if(player) {
				System.out.println("Has guanyat!!");
			}
			else {
				System.out.println("Has perdut :'C");
			}
		}
}