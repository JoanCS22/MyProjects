package Vista;
import java.util.Scanner;
import Model.Coordenada;
import Model.Ship;

public class AccionsJugador {
	Scanner scanner;
	public AccionsJugador() {
		scanner = new Scanner(System.in);
	}
	
	public Coordenada tornJugador()  {
		boolean error = false;
		int fila = 0, columna = 0;
		do {
			if(error) {
				System.out.println("Aquest valor no es possible.");
				error = false;
			}
			System.out.println("Introdueix la fila que vol probar:");
			String scannerFila = scanner.next();
			
			try {
			    fila = Integer.parseInt(scannerFila);
			    
			} catch (NumberFormatException e) {
				error = true;
			}
			if(fila > 10 || fila < 0) {
				error = true;
			}
		} while(error);
		
		error = false;
		do {
			if(error) {
				System.out.println("Aquest valor no es possible.");
				error = false;
			}
			System.out.println("Introdueix la columna que vol probar:");
			String scannerCol = scanner.next();
			try {
				columna = Integer.parseInt(scannerCol);
			    
			} catch (NumberFormatException e) {
				error = true;
			}
			if(columna > 10 || columna < 0) {
				error = true;
			}
		} while(error);
		
		System.out.println("Has introduït " + fila + " i " + columna);
		
		return new Coordenada(fila, columna);
	}

	public int[] posicionarVaixells(Ship ship) {
		int[] llista = new int[3];
		int fila = 0, columna = 0, horitzontal = 0;
		boolean error = false;
		System.out.println("El vaixell " + ship.getName() + " ocupa " + ship.getSize() + " caselles");
		
		do {
			if(error) {
				System.out.println("Aquest valor no es possible.");
				error = false;
			}
			
			System.out.println("Introdueix una fila per introduir-lo:");
			String scannerFila = scanner.next();
			
			try { fila = Integer.parseInt(scannerFila); } 
			catch (NumberFormatException e) { error = true; }
			
			if(fila > 10 || fila < 0) { error = true; }
		} while(error);
		
		llista[0] = fila;
		error = false;
		do {
			if(error) {
				System.out.println("Aquest valor no es possible.");
				error = false;
			}
			
			System.out.println("Introdueix una columna per introduir-lo:");
			String scannerColumna = scanner.next();
			
			try { columna = Integer.parseInt(scannerColumna); } 
			catch (NumberFormatException e) { error = true; }
			
			if(columna > 10 || columna < 0) { error = true; }
			
		} while(error);
		
		llista[1] = columna;
		error = false;
		
		do { 
			if(error) {
				System.out.println("Aquest valor no es possible.");
				error = false;
			}
			System.out.println("Introdueix 1 si vols que el vaixell estigui en horitzontal o 0 si vols que estigui en vertical:");
			String scannerHoritzontal = scanner.next();
			
			try { horitzontal = Integer.parseInt(scannerHoritzontal); } 
			catch (NumberFormatException e) { error = true; }
			
			if(!(horitzontal == 0 || horitzontal == 1)) { error = true; }
		} while(error);
		
		llista[2] = horitzontal;
		
		return llista;
	}

}