//Classe que representa una coordenada (int, int)
package Model;

public class Coordenada {

	private int row;
	private int column;
	
	public Coordenada(int x, int y) {
		this.row = x;
		this.column = y;
		
		assert(this.row == x);
		assert(this.column == y);
	}
	
	public int getRow() { return this.row; }
	public int getCol() { return this.column; }
	
	public boolean equals(Coordenada c)
	{
		assert(c.getCol() >= 0);
		assert(c.getRow() >= 0);
		assert(c.getCol() < 10);
		assert(c.getRow() < 10);
		
		if((this.row == c.row)&&(this.column == c.column))
			return true;
		
		return false;	
	}
}
