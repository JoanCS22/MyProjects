package Model;

public class Cell {
	private Ship ship;
	private boolean guessed;
	
	public Cell() {
		// TODO Auto-generated constructor stub	
		this.ship = null;
		this.guessed = false;
	}
	
	public Cell(Ship ship, boolean guessed)
	{
		assert(ship != null);
		
		this.ship = ship;
		this.guessed = guessed;
		
		assert(this.ship == ship);
		assert(this.guessed == guessed);
	}
	
	public Ship getShip() { return this.ship; }
	public void setShip(Ship ship) { this.ship = ship;}
	public boolean isGuessed() { return this.guessed; }
	public void setGuessed(boolean guessed) { 
		this.guessed = guessed; 
		assert(this.guessed == guessed);
	} 

}