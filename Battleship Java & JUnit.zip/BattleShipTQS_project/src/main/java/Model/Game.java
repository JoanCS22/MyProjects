package Model;

public class Game {
	private static int N_FILES = 10;
	private static int N_COLUMNES = 10;
	private static Ship[] ships = { new Ship("Carrier", 5), new Ship("Battleship", 4),
			new Ship("Destroyer", 3), new Ship("Submarine", 3), new Ship("Patrol Boat", 2)};
	
	private Board taulerPlayer, taulerRandom;
	private RandomPlayer random;
	
	public Game() {
		assert(ships.length > 0);
		
		taulerPlayer = new Board(N_FILES, N_COLUMNES, ships);
		taulerRandom = new Board(N_FILES, N_COLUMNES, ships);
		random = new RandomPlayer();
	}
	
	public Ship[] getShips() {
		return ships;
	}
	
	public Board getPlayerBoard() {
		return taulerPlayer;
	}
	
	public Board getRandomPlayerBoard() {
		return taulerRandom;
	}
	
	public RandomPlayer getRandomPlayer() {
		return random;
	}
	
	public int dispararVaixell(Coordenada coordenada, boolean player) {
		assert(coordenada != null);
		
		int res = -1; 
		if(player) {
			res = taulerRandom.dispararCasella(coordenada);
		}
		else {
			res = taulerPlayer.dispararCasella(coordenada);
			System.out.println("El teu enemic ha atacat a la posició: " + coordenada.getRow() + " " + coordenada.getCol());
		}
		return res;
	}
	
	public boolean placeShip(Ship s, Coordenada inici, boolean horitzontal, boolean player) {
		assert(inici != null);
		assert(s != null);
		
		if(player) {
			return taulerPlayer.placeShip(s, inici, horitzontal);
		}
		else {
			return taulerRandom.placeShip(s, inici, horitzontal);
		}
	}
	
	public boolean isOver(boolean player) {
		if(player) {
			return (taulerRandom.getVaixellsRestants() == 0);
		}
		else { 
			return (taulerPlayer.getVaixellsRestants() == 0);
		}
	}
}