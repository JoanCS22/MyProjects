package Model;

//NO ES POT TESTEJAR

import java.util.Random;

public class NumGenerator {

    private Random random;

    public NumGenerator(Random random) {
        this.random = random;
    }

    public NumGenerator() {
        this.random = new Random();
    }

    public int nextInt(int limit) {
        assert(limit > 0);
        return random.nextInt(limit);
    }
}
