package Model;

public class Board {

	private int numFiles;
	private int numColumnes;
	private Cell[][] tauler;
	private String[] shipNames;
	private boolean[] shipsPlaced;
	private int vaixellsRestants;
		
	public Board(int files, int columnes, Ship[] ships)
	{
		assert(files > 0);
		assert(columnes > 0); 
		assert(ships != null);
		
		numFiles = files;
		numColumnes = columnes;
		tauler = new Cell[numFiles][numColumnes];
		vaixellsRestants = ships.length;
		
		for(int fila = 0; fila < numFiles; fila++)
		{
			for(int col = 0; col < numColumnes; col++)
				tauler[fila][col] = new Cell();
		}
		
		shipNames = new String[ships.length];
		shipsPlaced = new boolean[ships.length];
		
		for(int i = 0; i < ships.length; i++)
		{
			shipNames[i] = ships[i].getName();
			shipsPlaced[i] = false;
		}
		
		assert(this.numFiles == files);
		assert(this.numColumnes == columnes);
		assert(this.shipNames.length == ships.length);
		assert(this.shipsPlaced.length == ships.length);
		assert(this.vaixellsRestants == ships.length);
	}
	
	public int getNFiles() { return this.numFiles; }
	public int getNColumnes() { return this.numColumnes; }
	public String[] getShipNames() { return shipNames; }
	public Cell getCasella(int fila, int columna) { 
		assert(fila >= 0);
		assert(columna >= 0);
		assert(fila < this.numFiles);
		assert(columna < this.numColumnes);
		
		return this.tauler[fila][columna]; 
	}
	
	public int getVaixellsRestants() { return vaixellsRestants; }
	
	public boolean getCasellaOcupada(int fila, int col) 
	{ 
		assert(fila >= 0 && fila < numFiles);
		assert(col >= 0 && col < numColumnes);
		
		return tauler[fila][col].getShip() != null; 
	}
	
	public boolean placeShip(Ship s, Coordenada inici, boolean horitzontal)
	{
		assert(s != null);
		assert(inici != null);
		
		int shipSize = s.getSize();  
		
		for(int i = 0; i < shipNames.length; i++)
		{
			if(shipNames[i] == s.getName() && shipsPlaced[i] == true)
				return false;
		}
		
		if(inici.getRow() >= 0 && inici.getRow() < 10  && inici.getCol() >= 0 && inici.getCol() < 10  && comprovaCoordenadesNoOcupades(shipSize, inici, horitzontal))
		{
			if(horitzontal)
			{
				int colInici = inici.getCol();
				int fila = inici.getRow();
				
				if(colInici + shipSize <= 10)
				{
					for(int i = 0; i < shipNames.length; i++)
					{
						if(shipNames[i].equals(s.getName()))
							shipsPlaced[i] = true;
					}
					for(int col = colInici; col < (shipSize + colInici); col++)
						tauler[fila][col].setShip(s); 
					
					return true;
				}
			}
			else {
				int filaInici = inici.getRow();
				int col = inici.getCol();
				
				
				if(filaInici + shipSize <= 10)
				{
					for(int i = 0; i < shipNames.length; i++)
					{
						if(shipNames[i].equals(s.getName()))
							shipsPlaced[i] = true;
					}
					
					for(int fila = filaInici; fila < (shipSize + filaInici); fila++)
						tauler[fila][col].setShip(s);
					
					return true;
				}
			}
		}
		
		return false;
	}
	
	private boolean comprovaCoordenadesNoOcupades(int size, Coordenada inici, boolean hor)
	{
		assert(inici != null);
		assert(size > 0);
		assert(size <= 5);
		
		if(hor && inici.getCol() + size <= 10)
		{
			int colInici = inici.getCol();
			int limit = size + colInici - 1;
			int fila = inici.getRow();
			
			for(int col = colInici; col <= limit; col++)
			{
				if(getCasellaOcupada(fila, col))
					return false;
			}
		}
		else
		{
			if(inici.getRow() + size <= 10)
			{
				int filaInici = inici.getRow();
				int limit = size + filaInici - 1;
				int col = inici.getCol();
				
				for(int fila = filaInici; fila <= limit; fila++)
				{
					if(getCasellaOcupada(fila, col))
						return false; 
				}
			}
		}
	
		return true;
	}	
		
	//Mètode retorna true si s'ha pogut disparar al tauler (Coordenada dins el tauler, i a més no ha estat disparada abans)
	public int dispararCasella(Coordenada c)
	{
		assert(c != null);
		
		int vaixellsInici = this.vaixellsRestants;
		
		//-1 = error, 0 = aigua, 1 = tocat vaixell, 2 = enfonsar vaixell
		int fila = c.getRow();
		int col = c.getCol();
		
		if(fila >= 0 && fila < this.getNFiles() && col >= 0 && col < this.getNColumnes())
		{
			if(!this.tauler[fila][col].isGuessed())
			{
				this.tauler[fila][col].setGuessed(true);
				Ship possible = this.tauler[fila][col].getShip();
				
				if(possible != null)
				{
					possible.hitShip();
					
					if(possible.isSunk()) {
						vaixellsRestants--;
						assert(this.vaixellsRestants == vaixellsInici - 1);
						return 2;
					}
					
					assert(this.vaixellsRestants == vaixellsInici);
					return 1;
				}
				
				assert(this.vaixellsRestants == vaixellsInici);
				return 0;
			}
		}
		
		assert(this.vaixellsRestants == vaixellsInici);
		return -1;
	}
	
	int calcularPuntuacio(int vaixellsEnfonsats, boolean carrierEnfonsat, boolean petitEnfonsat) {
		
		assert(vaixellsEnfonsats >= 0);
		assert(vaixellsEnfonsats <= shipNames.length);
		
		int puntuacio = 0;
		
		if(vaixellsEnfonsats != 0) {
			puntuacio = vaixellsEnfonsats * 5;
			
			if(carrierEnfonsat) {
				puntuacio += 15;
			}
			if(petitEnfonsat) {
				puntuacio += 10;
			}
			
			assert(puntuacio != 0);
		}
		
		return puntuacio;
	}	
}