package Model;

public class MockShip extends Ship {

	public MockShip(String n, int s) { super(n, s); }

	public int getSize() { return 5; }
} 
