package Model;

public class RandomPlayer {
	
	private NumGenerator numGenerator;
	
	public RandomPlayer() {
		this.numGenerator = new NumGenerator();
	}
	
	public void setNumGenerator(NumGenerator ng) { this.numGenerator = ng; }

	public Coordenada generateCoordenadaAtac(Board board) {
		
		assert(board != null);
		
		Coordenada coord = null;
		int i = 0;
		int j = 0;
		boolean casellaAmbVaixell = false;
		
		if(board.getNFiles() <= 0)
			casellaAmbVaixell = true;
		
		Coordenada finalCoord = null;
		
		while(!casellaAmbVaixell && i < board.getNFiles()) {
			
			j = 0;
			
			if(board.getNColumnes() <= 0)
				casellaAmbVaixell = true;
			
			while(!casellaAmbVaixell && j < board.getNColumnes()) {
				
				if(board.getCasellaOcupada(i, j)) {
					Ship hitShip = board.getCasella(i, j).getShip();
					
					if(!hitShip.isSunk()) {
						coord = new Coordenada(i, j);
					}
				} 
				
				j++;
			}
			
			i++;
		}
		
		if(coord != null) {
			finalCoord = this.atacCoordenadaInteligent(coord, board.getNFiles(), board.getNColumnes());
		} else {
			
			int fila, columna;
			
			do {
				fila = this.numGenerator.nextInt(board.getNFiles());
				columna = this.numGenerator.nextInt(board.getNColumnes());
			} while (board.getCasellaOcupada(fila, columna));
			
			finalCoord = new Coordenada(fila, columna);
		}
		
		return finalCoord;
	}
	
	public Coordenada getCoordenadaInteligent(Coordenada c, int files, int columnes) {
		return this.atacCoordenadaInteligent(c, files, columnes);
	}
	
	private Coordenada atacCoordenadaInteligent(Coordenada c, int files, int columnes) {
		
		assert(c.getRow() >= 0);
		assert(c.getRow() < files);
		assert(c.getCol() >= 0);
		assert(c.getCol() < columnes);
		
		Coordenada coord = null;
		int targetRow = c.getRow();
		int targetCol = c.getCol();
		
		if(targetRow > 0) {
			coord = new Coordenada(targetRow - 1, targetCol);
		} else if (targetCol < columnes - 1) {
			coord = new Coordenada(targetRow, targetCol + 1);
		} else if (targetRow < files - 1) {
			coord = new Coordenada(targetRow + 1, targetCol);
		} else {
			coord = new Coordenada(targetRow, targetCol - 1);
		}
		
		return coord;
	}
	
	public Coordenada coordToPlaceShip(Board board) {
		int fila = this.numGenerator.nextInt(board.getNFiles());
		int columna = this.numGenerator.nextInt(board.getNColumnes());
		return new Coordenada(fila, columna);
	}
	
	public int selectShipDirection() {
		return this.numGenerator.nextInt(2);
	}
}
