package Model;

public class Ship {
	
	private String name;
	private int size;
	private int hits;
	
	public Ship(String n, int s) 
	{
		assert(s > 0);
		
		this.name = n;
		this.size = s;
		this.hits = 0;
		
		assert(this.hits == 0);
		assert(this.name == n);
		assert(this.size == s);
	}
	
	public String getName() { return this.name; }
	public int getSize() { return this.size; }
	public int getNHits() { return this.hits; }
	
	public boolean isSunk() { 
		assert(this.hits <= this.size);
		
		return this.size == this.hits;  
	}

	public void hitShip() 
	{  
		//Comprovem que el tamany sigui major que els cops que li han donat
		assert(this.size > this.hits);
		int initHits = this.hits;
		
		this.hits++;
		
		assert(this.hits == initHits+1);
	}
}
