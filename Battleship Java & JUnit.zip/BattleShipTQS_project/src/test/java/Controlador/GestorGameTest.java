package Controlador;

import static org.junit.jupiter.api.Assertions.*;
import Model.Game;
import Model.Board;
import Model.Coordenada;
import Vista.MockAccionsJugador;
import Vista.AccionsJugador;
import Model.RandomPlayer;
import Model.Ship;

import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

//-Dnet.bytebuddy.experimental=true --> APlicar això a Run --> Run Configurations --> Arguments --> Copiar a VM arguments


public class GestorGameTest {
	Game partida;
	MockAccionsJugador mock;
	
	@BeforeEach
	void setUp() {
		partida = new Game();
		mock = new MockAccionsJugador();
	}
	
	@Test
	void testGestorGameTest() {
		GestorGame gestor = new GestorGame(partida);
		assertNotNull(gestor.getPartida());
		assertEquals(gestor.getPartida(), partida);
		assertNotNull(gestor.getAccions());
		assertNotNull(gestor.getPrinter());
	}
	
	@Test
	void testCrearPartida() {
		// Pendent comprovar amb mock random player
		GestorGame gestor = new GestorGame(partida);
		gestor.setAccions(mock);
		gestor.crearPartida();
		
		Board taulerPlayer = gestor.getPartida().getPlayerBoard();
		for(int i = 1; i < 6; i++) {
			assertTrue(taulerPlayer.getCasellaOcupada(0, i));
		}
		assertFalse(taulerPlayer.getCasellaOcupada(0, 0));
		assertFalse(taulerPlayer.getCasellaOcupada(0, 6));
		
		for(int i = 5; i < 9; i++) {
			assertTrue(taulerPlayer.getCasellaOcupada(i, 2));
		}
		assertFalse(taulerPlayer.getCasellaOcupada(4, 2));
		assertFalse(taulerPlayer.getCasellaOcupada(9, 2));
		
		for(int i = 7; i < 10; i++) {
			assertTrue(taulerPlayer.getCasellaOcupada(4, i));
		}
		assertFalse(taulerPlayer.getCasellaOcupada(4, 6));
		
		for(int i = 6; i < 9; i++) {
			assertTrue(taulerPlayer.getCasellaOcupada(i, 8));
		}
		assertFalse(taulerPlayer.getCasellaOcupada(5, 8));
		assertFalse(taulerPlayer.getCasellaOcupada(9, 8));
		
		for(int i = 2; i < 4; i++) {
			assertTrue(taulerPlayer.getCasellaOcupada(i, 4));
		}
		assertFalse(taulerPlayer.getCasellaOcupada(1, 4));
		assertFalse(taulerPlayer.getCasellaOcupada(4, 4));
	}
	
	@Test
	void testCrearPartida_ConditionCoverage() {
	    GestorGame gestor = new GestorGame(partida);
	    gestor.setAccions(mock);

	    Board randomPlayerBoard = gestor.getPartida().getRandomPlayerBoard();
	    randomPlayerBoard.placeShip(new Ship("Prova", 1), new Coordenada(0,0), false); 
	   
	    gestor.crearPartida();

	    Board taulerPlayer = gestor.getPartida().getPlayerBoard();
	    
	    for (int i = 1; i < 6; i++) {
	        assertTrue(taulerPlayer.getCasellaOcupada(0, i)); 
	    }
	    assertFalse(taulerPlayer.getCasellaOcupada(0, 0)); 
	    assertFalse(taulerPlayer.getCasellaOcupada(0, 6)); 

	    for (int i = 1; i < 4; i++) {
	        assertFalse(randomPlayerBoard.getCasellaOcupada(1, i)); 
	    }
	    
	    assertTrue(randomPlayerBoard.getCasellaOcupada(0, 0)); 
	}

	
	@Test
    public void testDispararVaixellPlayerJugador() {
        Game gameMock = mock(Game.class);
        AccionsJugador accionsMock = mock(AccionsJugador.class);

        Coordenada coordenadaMock = new Coordenada(3, 3);
        when(accionsMock.tornJugador()).thenReturn(coordenadaMock); 
        when(gameMock.dispararVaixell(coordenadaMock, true)).thenReturn(1); 
        Board randomPlayerBoardMock = mock(Board.class);
        when(gameMock.getRandomPlayerBoard()).thenReturn(randomPlayerBoardMock);

        GestorGame gestorGame = new GestorGame(gameMock);
        gestorGame.setAccions(accionsMock); 
        gestorGame.getPrinter().printBoard(true, randomPlayerBoardMock);
        
        boolean result = gestorGame.dispararVaixellPlayer(true);

        verify(accionsMock).tornJugador();
        verify(gameMock).dispararVaixell(coordenadaMock, true);

        assertTrue(result); 
    }

	@Test
	public void testDispararVaixellPlayerRandom() {
	    Game gameMock = mock(Game.class);
	    RandomPlayer randomPlayerMock = mock(RandomPlayer.class); 
	    Board randomPlayerBoardMock = mock(Board.class);

	    Coordenada coordenadaMock = new Coordenada(5, 5);
	    when(gameMock.getRandomPlayer()).thenReturn(randomPlayerMock); 
	    when(gameMock.getRandomPlayerBoard()).thenReturn(randomPlayerBoardMock); 
	    when(randomPlayerMock.coordToPlaceShip(randomPlayerBoardMock)).thenReturn(coordenadaMock); 
	    when(gameMock.dispararVaixell(coordenadaMock, false)).thenReturn(0); 

	    GestorGame gestorGame = new GestorGame(gameMock);

	    boolean result = gestorGame.dispararVaixellPlayer(false);

	    verify(gameMock).getRandomPlayer();
	    verify(randomPlayerMock).coordToPlaceShip(randomPlayerBoardMock);
	    verify(gameMock).dispararVaixell(coordenadaMock, false);

	    assertTrue(result); 
	}

	@Test
	public void testPartida() {
	    Game gameMock = mock(Game.class);

	    when(gameMock.isOver(anyBoolean())).thenReturn(false, false, true); 
	    GestorGame gestorGameSpy = spy(new GestorGame(gameMock)); // Crear un espia de la classe provada
	    doReturn(true).when(gestorGameSpy).dispararVaixellPlayer(anyBoolean()); 

	    gestorGameSpy.partida();

	    verify(gameMock, times(3)).isOver(anyBoolean()); 
	    verify(gestorGameSpy, atLeast(2)).dispararVaixellPlayer(anyBoolean()); 
	}
}
