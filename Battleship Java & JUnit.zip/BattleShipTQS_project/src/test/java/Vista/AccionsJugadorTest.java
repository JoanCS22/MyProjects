package Vista;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import Model.Coordenada;
import Model.Ship;


class AccionsJugadorTest {
	MockAccionsJugador mock; 
	
	@BeforeEach
	void setUp() {
		mock = new MockAccionsJugador();
	}
	
	@Test
	void testTornJugador() {
        int index = 0;
		System.setIn(mock.inputTornJugador(index));
		AccionsJugador accionsJugador = new AccionsJugador();
		Coordenada coordenada = accionsJugador.tornJugador();
		assertNotNull(coordenada);
	    assertEquals(1, coordenada.getRow());
	    assertEquals(2, coordenada.getCol());
	    index++;
	    
	    System.setIn(mock.inputTornJugador(index));
	    accionsJugador = new AccionsJugador(); 
	    Coordenada coordenada1 = accionsJugador.tornJugador();
		assertNotNull(coordenada1);
	    assertEquals(2, coordenada1.getRow());
	    assertEquals(4, coordenada1.getCol());
	    index++;
	    
	    System.setIn(mock.inputTornJugador(index));
	    accionsJugador = new AccionsJugador(); 
	    Coordenada coordenada2 = accionsJugador.tornJugador();
		assertNotNull(coordenada2);
	    assertEquals(5, coordenada2.getRow());
	    assertEquals(7, coordenada2.getCol());
	    index++;
	    
	    System.setIn(mock.inputTornJugador(index));
	    accionsJugador = new AccionsJugador(); 
	    Coordenada coordenada3 = accionsJugador.tornJugador();
		assertNotNull(coordenada3);
	    assertEquals(9, coordenada3.getRow());
	    assertEquals(3, coordenada3.getCol());
	    index++;
	    
	    System.setIn(mock.inputTornJugador(index));
	    accionsJugador = new AccionsJugador(); 
	    Coordenada coordenada4 = accionsJugador.tornJugador();
		assertNotNull(coordenada4);
	    assertEquals(7, coordenada4.getRow());
	    assertEquals(0, coordenada4.getCol());
	    index++;
	    
	    System.setIn(mock.inputTornJugador(index));
	    accionsJugador = new AccionsJugador(); 
	    Coordenada coordenada5 = accionsJugador.tornJugador();
		assertNotNull(coordenada5);
	    assertEquals(7, coordenada5.getRow());
	    assertEquals(0, coordenada5.getCol());
	    index++;
	    
	    System.setIn(mock.inputTornJugador(index));
	    accionsJugador = new AccionsJugador(); 
	    Coordenada coordenada6 = accionsJugador.tornJugador();
		assertNotNull(coordenada6);
	    assertEquals(1, coordenada6.getRow());
	    assertEquals(0, coordenada6.getCol());
	    index++;
	    
	    System.setIn(mock.inputTornJugador(index));
	    accionsJugador = new AccionsJugador(); 
	    Coordenada coordenada7 = accionsJugador.tornJugador();
		assertNotNull(coordenada7);
	    assertEquals(1, coordenada7.getRow());
	    assertEquals(0, coordenada7.getCol());
	    index++;

        System.setIn(System.in);
	}
	
	@Test
	void testPosicionarVaixells() {
		int index = 0;

		Ship ship = new Ship("Patrol Boat", 2);
		
		System.setIn(mock.inputPosicionarVaixells(index));
		AccionsJugador accionsJugador = new AccionsJugador();
		int[] llista = accionsJugador.posicionarVaixells(ship);
		assertNotNull(llista);
		assertEquals(llista[0], 1);
		assertEquals(llista[1], 2);
		assertEquals(llista[2], 0);
		index++;
		
		System.setIn(mock.inputPosicionarVaixells(index));
		accionsJugador = new AccionsJugador(); 
		llista = accionsJugador.posicionarVaixells(ship);
		assertNotNull(llista);
		assertEquals(llista[0], 2);
		assertEquals(llista[1], 4);
		assertEquals(llista[2], 1);
		index++;
		
		System.setIn(mock.inputPosicionarVaixells(index));
		accionsJugador = new AccionsJugador(); 
		llista = accionsJugador.posicionarVaixells(ship);
		assertNotNull(llista);
		assertEquals(llista[0], 5);
		assertEquals(llista[1], 7);
		assertEquals(llista[2], 1);
		index++;
		
		System.setIn(mock.inputPosicionarVaixells(index));
		accionsJugador = new AccionsJugador(); 
		llista = accionsJugador.posicionarVaixells(ship);
		assertNotNull(llista);
		assertEquals(llista[0], 9);
		assertEquals(llista[1], 3);
		assertEquals(llista[2], 0);
		index++;
		
		System.setIn(mock.inputPosicionarVaixells(index));
		accionsJugador = new AccionsJugador(); 
		llista = accionsJugador.posicionarVaixells(ship);
		assertNotNull(llista);
		assertEquals(llista[0], 7);
		assertEquals(llista[1], 0);
		assertEquals(llista[2], 0);
		index++;
	}
}