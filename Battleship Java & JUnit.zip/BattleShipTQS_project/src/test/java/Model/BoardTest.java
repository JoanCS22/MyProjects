package Model;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class BoardTest {

	Board b1, b2, b3;
	Ship s1, s2, s3, s4, s5;
	@BeforeEach
	void setUp()
	{
		Ship[] s = new Ship[5];
		Ship[] ships1 = new Ship[1];
		s1 = new Ship("Carrier", 5);
		s2 = new Ship("Battleship", 4);
		s3 = new Ship("Destroyer", 3);
		s4 = new Ship("Submarine", 3);
		s5 = new Ship("Patrol Boat", 2); 
		
		s[0] = s1;
		s[1] = s2;
		s[2] = s3;
		s[3] = s4;
		s[4] = s5;
		
		ships1[0] = s1;
		
		b1 = new Board(10, 10, s);
		b2 = new Board(15, 15, s);
		b3 = new Board(10, 10, ships1);
	}
	
	
	@Test
	void test() {
		assertEquals(10, b1.getNFiles());
		assertEquals(10, b1.getNColumnes());
		Ship[] s = new Ship[1];
		s[0] = new Ship("Prova", 1);
		
		assertEquals(15, b2.getNFiles());
		assertEquals(15, b2.getNColumnes());
		
		for(int fila = 0; fila < 10; fila++)
		{
			for(int columna = 0; columna < 10; columna++)
				assertFalse(b1.getCasellaOcupada(fila, columna));
		}
	}

	@Test
	void testPlaceShip()
	{		
		// TESTS AMB CARRIER
		assertFalse(b1.placeShip(s1, new Coordenada(0,9), true)); // Límit dret
		assertFalse(b1.placeShip(s1, new Coordenada(-1,9), false)); // Límit superior
		assertFalse(b1.placeShip(s1, new Coordenada(0,-1), true)); // Límit esquerra
		assertFalse(b1.placeShip(s1, new Coordenada(9,0), false)); // Límit inferior
		 
		assertTrue(b1.placeShip(s1, new Coordenada(0,0), true)); //Es pot col·locar
		
		for(int i = 0; i < 5; i++) 
			assertTrue(b1.getCasellaOcupada(0, i)); //Comprovar que les caselles ara estan ocupades
		
		assertFalse(b1.getCasellaOcupada(0, 5)); //Comprovar casella següent no està ocupada
		assertFalse(b1.getCasellaOcupada(1, 0)); //Comprovar casella d'abaix no està ocupada
		
		assertFalse(b1.placeShip(s1, new Coordenada(3, 3), false)); //No es pot col·locar, ja està al tauler el tipus de vaixell
		
		// TESTS AMB BATTLESHIP
		assertFalse(b1.placeShip(s2, new Coordenada(0,0), true)); //Casella ocupada, intenta posar-se a sobre
		assertFalse(b1.placeShip(s2, new Coordenada(0,4), true)); //Casella ocupada, intenta ocupar ultimes caselles
		assertFalse(b1.placeShip(s2, new Coordenada(0,1), false)); //Casella ocupada, intenta posar-se en vertical en una casella ocupada
		
		assertTrue(b1.placeShip(s2, new Coordenada(0,5), true)); //Es pot col·locar
		
		for(int i = 5; i < 9; i++)
			assertTrue(b1.getCasellaOcupada(0, i));
		
		assertFalse(b1.getCasellaOcupada(0, 9)); //Comprovar casella següent no està ocupada
		assertFalse(b1.getCasellaOcupada(1, 5)); //Comprovar casella d'abaix no està ocupada
		
		assertFalse(b1.placeShip(s2, new Coordenada(3,3), false)); //Ja esta aquest tipus de vaixell
		
		// TESTS AMB DESTROYER <- vaig per aquí
		assertFalse(b1.placeShip(s3, new Coordenada(0, 3), true)); //Caselles ocupades per dos vaixells
		assertFalse(b1.placeShip(s3, new Coordenada(0, 3), false)); //Casella ocupada
		assertFalse(b1.placeShip(s3, new Coordenada(3, 10), true)); //No es pot colocar, posició fora del tauler en horitzontal
		assertFalse(b1.placeShip(s3, new Coordenada(10, 8), false)); //Posició fora del tauler en vertical
		
		assertTrue(b1.placeShip(s3, new Coordenada(7, 4), false)); //Bona colocació vertical, esta al límit pero cap
		
		for(int i = 7; i < 10; i++)
			assertTrue(b1.getCasellaOcupada(i, 4)); //Comprovar posicions en vertical
		
		assertFalse(b1.getCasellaOcupada(6, 4)); //Comprovar posició d'abans, no ocupada
		assertFalse(b1.getCasellaOcupada(7, 3)); //Comprovar posició esquerra, no ocupada
		assertFalse(b1.getCasellaOcupada(7, 5)); //Comprovar posició dreta, no ocupada
		
		assertFalse(b1.placeShip(s3, new Coordenada(3, 3), false)); //Aquest tipus de vaixell ja esta
		
		// TESTS AMB SUBMARINE
		assertFalse(b1.placeShip(s4, new Coordenada(10, 10), true)); //Fora del limit
		assertFalse(b1.placeShip(s4, new Coordenada(7, 3), true)); //Casella ocupada
		assertFalse(b1.placeShip(s4, new Coordenada(8, 3), false)); //Casella ocupada
		
		assertTrue(b1.placeShip(s4, new Coordenada(3, 0), false)); //Correcte
		
		for(int i = 3; i < 6; i++)
			assertTrue(b1.getCasellaOcupada(i, 0)); //Comprovar posicions en vertical
		
		assertFalse(b1.getCasellaOcupada(2, 0)); //Comprovar posició de després, no ocupada
		assertFalse(b1.getCasellaOcupada(6, 0)); //Comprovar posició de després, no ocupada
		assertFalse(b1.getCasellaOcupada(3, 1)); //Comprovar posició del costat, no ocupada
		assertFalse(b1.getCasellaOcupada(5, 1)); //Comprovar posició del costat, no ocupada
		
		assertFalse(b1.placeShip(s4, new Coordenada(3, 3), false)); //Aquest tipus de vaixell ja esta
		
		// TESTS AMB PATROL BOAT
		assertFalse(b1.placeShip(s5, new Coordenada(10, 5), false)); //casella fora del límit
		assertFalse(b1.placeShip(s5, new Coordenada(7, 4), false)); //Casella ocupada
		assertTrue(b1.placeShip(s5, new Coordenada(4, 8), true)); //Correcte
		
		for(int i = 8; i < 10; i++)
			assertTrue(b1.getCasellaOcupada(4, i)); //Comprovar posicions en vertical
		
		assertFalse(b1.getCasellaOcupada(4, 7)); //Comprovar posició d'abans, no ocupada
		assertFalse(b1.getCasellaOcupada(5, 8)); //Comprovar posició inferior, no ocupada
		assertFalse(b1.getCasellaOcupada(3, 8)); //Comprovar posició superior, no ocupada
		
		assertFalse(b1.placeShip(s5, new Coordenada(3, 3), true)); //Aquest tipus de vaixell ja esta
	}
	
	@Test
	void testDispararCasella(){
		//Comprovar en tauler buit si tot és aigua (salta un print d'aigua)
		for(int i = 0; i < b2.getNFiles(); i++)
		{
			for(int j = 0; j < b2.getNColumnes(); j++)
				assertTrue(b2.dispararCasella(new Coordenada(i,j)) == 0);
		}
		
		b1.placeShip(s1, new Coordenada(0,0), true);
		b1.placeShip(s2, new Coordenada(2,0), false);
		b1.placeShip(s5, new Coordenada(9, 8), true);
		
		for(int i = 0; i<s1.getSize(); i++) {
			assertTrue(b1.dispararCasella(new Coordenada(0,i)) > 0); //Totes les caselles ocupades del primer vaixell (hit)
			assertTrue(b1.dispararCasella(new Coordenada(0,i)) == -1); //Caselles ja disparades abans
			assertTrue(b1.dispararCasella(new Coordenada(1,i)) == 0); //Comprovar límits inferiors a les caselles del 1r vaixell (true, però aigua)
			assertTrue(b1.dispararCasella(new Coordenada(-1,i)) == -1); //Comprovar límits superiors (no es pot disparar)
		}
		
		
		assertTrue(b1.dispararCasella(new Coordenada(0, 5)) == 0); //Comprovar límit per la dreta del vaixell (aigua)
		assertTrue(b1.dispararCasella(new Coordenada(0, -1)) == -1); //Comprovar límit per esquerra (no es pot disparar)
		
		for(int fila = 2; fila < 2 + s2.getSize(); fila++)
		{
			assertTrue(b1.dispararCasella(new Coordenada(fila, 0)) > 0);
			assertTrue(b1.dispararCasella(new Coordenada(fila, 0)) == -1);
			assertTrue(b1.dispararCasella(new Coordenada(fila, 1)) == 0);
			assertTrue(b1.dispararCasella(new Coordenada(fila, -1)) == -1);
		}
	
		assertTrue(b1.dispararCasella(new Coordenada(6, 0)) == 0);
		assertTrue(b1.dispararCasella(new Coordenada(1,0)) == -1); //Ja disparada
		
		for(int col = 8; col < 8 + s5.getSize(); col++)
		{
			assertTrue(b1.dispararCasella(new Coordenada(9, col)) > 0);
			assertTrue(b1.dispararCasella(new Coordenada(9, col)) == -1);
			assertTrue(b1.dispararCasella(new Coordenada(8, col)) == 0); //No ocupades (aigua)
			assertTrue(b1.dispararCasella(new Coordenada(10, col)) == -1); //Fora del tauler
		}
		
		assertTrue(b1.dispararCasella(new Coordenada(9, 7)) == 0); //Aigua
		assertTrue(b1.dispararCasella(new Coordenada(9,10)) == -1); //fora del tauler
	}
	
	@Test
	void testGetCasella() {
		
		for(int i = 0; i < b1.getNFiles(); i++)
		{
			for(int j = 0; j < b1.getNFiles(); j++)
			{
				Cell c = b1.getCasella(0, 0);
				assertNull(c.getShip());
				assertFalse(c.isGuessed());
			}
		}	
		
		MockShip s = new MockShip("Carrier", 5); 
		b1.placeShip(s, new Coordenada(0,0), true);
		
		for(int col = 0; col < s.getSize(); col++)
		{
			Cell c = b1.getCasella(0, col);
			assertFalse(c.isGuessed());
		}
		
		for(int col = 0; col < s.getSize(); col++)
			b1.dispararCasella(new Coordenada(0, col));
		
		for(int col = 0; col < s.getSize(); col++)
		{
			Cell c = b1.getCasella(0, col);
			assertNotNull(c.getShip());
			assertTrue(c.isGuessed());
		}
	}
	
	@Test
	void testGetShipNames() {
		String[] shipNames =  b1.getShipNames();
		
		assertNotNull(shipNames);
		
		assertEquals(shipNames[0], "Carrier");
		assertEquals(shipNames[1], "Battleship");
		assertEquals(shipNames[2], "Destroyer");
		assertEquals(shipNames[3], "Submarine");
		assertEquals(shipNames[4], "Patrol Boat");
	}
	
	//Test per fer pairwise testing
	//Tres entrades: vaixellsEnfonsats (0,1,2,3,4,5), carrierEnfonsat (true, false) i vaixellPetitEnfonsat (true, false) 
	//Fent pairwise testing, necessitem un total de 12 combinacions només per a cobrir tots els casos
	@Test
	void testPuntuacioRival() {
		assertTrue(b1.calcularPuntuacio(0, true, true) == 0);
		assertTrue(b1.calcularPuntuacio(0, false, false) == 0);
		
		assertTrue(b1.calcularPuntuacio(1, true, false) == 20);
		assertTrue(b1.calcularPuntuacio(1, false, true) == 15);
		
		assertTrue(b1.calcularPuntuacio(2, true, true) == 35);
		assertTrue(b1.calcularPuntuacio(2, false, false) == 10);
		
		assertTrue(b1.calcularPuntuacio(3, true, false) == 30);
		assertTrue(b1.calcularPuntuacio(3, false, true) == 25);
		
		assertTrue(b1.calcularPuntuacio(4, true, true) == 45);
		assertTrue(b1.calcularPuntuacio(4, false, false) == 20);
		
		assertTrue(b1.calcularPuntuacio(5, true, false) == 40);
		assertTrue(b1.calcularPuntuacio(5, false, true) == 35);
	}
	
	@Test
	void testGetVaixellsRestants() {
		assertEquals(b1.getVaixellsRestants(), 5);
		assertEquals(b2.getVaixellsRestants(), 5);
		assertEquals(b3.getVaixellsRestants(), 1);
	}

}