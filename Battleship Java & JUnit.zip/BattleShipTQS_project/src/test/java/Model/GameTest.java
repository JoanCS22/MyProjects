package Model;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class GameTest {
	
	RandomPlayer p;
	Game game;
	
	@BeforeEach
	void setUp() {
		game = new Game();
	}
	
	@Test
	void testGame() {
		Board taulerP, taulerR;
		
		taulerP = game.getPlayerBoard();
		taulerR = game.getRandomPlayerBoard();
		
		assertNotNull(taulerP);
		assertNotNull(taulerR);
		assertNotNull(game.getRandomPlayer());
		
		assertEquals(taulerP.getNFiles(), 10);
		assertEquals(taulerP.getNColumnes(), 10);
		
		String[] shipNames = taulerP.getShipNames();
		Ship[] ships = game.getShips();
		for(int i = 0; i < shipNames.length; i++) {
			assertNotNull(shipNames[i]);
			assertEquals(shipNames[i], ships[i].getName());
		}
			
		assertEquals(taulerR.getNFiles(), 10);
		assertEquals(taulerR.getNColumnes(), 10);
		
		shipNames = taulerR.getShipNames();
		for(int i = 0; i < shipNames.length; i++) {
			assertNotNull(shipNames[i]);
		}
		
		assertEquals(shipNames[0], "Carrier");
		assertEquals(shipNames[1], "Battleship");
		assertEquals(shipNames[2], "Destroyer");
		assertEquals(shipNames[3], "Submarine");
		assertEquals(shipNames[4], "Patrol Boat");
	}
	
	@Test
	void testDispararVaixell() {
		
		game.placeShip(new Ship("Submarine", 3), new Coordenada(1,2), false, false);
		
		assertEquals(game.dispararVaixell(new Coordenada(-1, 2), true), -1);
		assertEquals(game.dispararVaixell(new Coordenada(1, -2), true), -1);
		assertEquals(game.dispararVaixell(new Coordenada(11, 2), true), -1);
		assertEquals(game.dispararVaixell(new Coordenada(1, 10), true), -1);
		
		assertEquals(game.dispararVaixell(new Coordenada(1, 2), true), 1);
		assertEquals(game.dispararVaixell(new Coordenada(2, 2), true), 1);
		assertEquals(game.dispararVaixell(new Coordenada(3, 2), true), 2);
		assertEquals(game.dispararVaixell(new Coordenada(3, 9), true), 0);
		assertEquals(game.dispararVaixell(new Coordenada(8, 4), true), 0);
		
		game.placeShip(new Ship("Carrier", 5), new Coordenada(3,8), false, true);
		
		assertEquals(game.dispararVaixell(new Coordenada(3, 8), false), 1);
		assertEquals(game.dispararVaixell(new Coordenada(4, 8), false), 1);
		assertEquals(game.dispararVaixell(new Coordenada(5, 8), false), 1);
		assertEquals(game.dispararVaixell(new Coordenada(6, 8), false), 1);
		assertEquals(game.dispararVaixell(new Coordenada(7, 8), false), 2);
		assertEquals(game.dispararVaixell(new Coordenada(2, 8), false), 0);
		assertEquals(game.dispararVaixell(new Coordenada(8, 8), false), 0);
		
	}
	
	@Test
	void testPlaceShip() {
		//Test player
		Ship[] ships = { new Ship("Carrier", 5), new Ship("Battleship", 4), new Ship("Destroyer", 3)} ;
		for (int i = 0; i < ships.length; i++) {
			game.placeShip(ships[i], new Coordenada(i+1,i+2), true, true);
			assertTrue(game.getPlayerBoard().getCasellaOcupada(i+1, i+2));
		}
		
		for (int i = 0; i < ships.length; i++) {
			game.placeShip(ships[i], new Coordenada(i+1,i+2), true, false);
			assertTrue(game.getRandomPlayerBoard().getCasellaOcupada(i+1, i+2));
		}
	}

	@Test
	void testOver() {
		
		assertFalse(game.isOver(true));
		assertFalse(game.isOver(false));
		
		// 1r coloquem tots els vaixells al jugador aleatori
		game.placeShip(new Ship("Carrier", 5), new Coordenada(0,0), false, false);
		game.placeShip(new Ship("Battleship", 4), new Coordenada(1,1), false, false);
		game.placeShip(new Ship("Destroyer", 3), new Coordenada(2,2), false, false);
		game.placeShip(new Ship("Submarine", 3), new Coordenada(3,3), false, false);
		game.placeShip(new Ship("Patrol Boat", 2), new Coordenada(4,4), false, false);
		
		// Enfonsem el vaixell de 5
		game.dispararVaixell(new Coordenada(0, 0), true);
		game.dispararVaixell(new Coordenada(1, 0), true);
		game.dispararVaixell(new Coordenada(2, 0), true);
		game.dispararVaixell(new Coordenada(3, 0), true);
		game.dispararVaixell(new Coordenada(4, 0), true);
		assertEquals(game.getRandomPlayerBoard().getVaixellsRestants(), 4);
		assertFalse(game.isOver(true));
		
		// Enfonsem el vaixell de 4
		game.dispararVaixell(new Coordenada(1, 1), true);
		game.dispararVaixell(new Coordenada(4, 1), true);
		game.dispararVaixell(new Coordenada(2, 1), true);
		game.dispararVaixell(new Coordenada(3, 1), true);
		assertEquals(game.getRandomPlayerBoard().getVaixellsRestants(), 3);
		assertFalse(game.isOver(true));
		
		// Enfonsem el vaixell de 3
		game.dispararVaixell(new Coordenada(2, 2), true);
		game.dispararVaixell(new Coordenada(3, 2), true);
		game.dispararVaixell(new Coordenada(4, 2), true);
		assertEquals(game.getRandomPlayerBoard().getVaixellsRestants(), 2);
		assertFalse(game.isOver(true));
		
		// Enfonsem el vaixell de 3
		game.dispararVaixell(new Coordenada(3, 3), true);
		game.dispararVaixell(new Coordenada(4, 3), true);
		game.dispararVaixell(new Coordenada(5, 3), true);
		assertEquals(game.getRandomPlayerBoard().getVaixellsRestants(), 1);
		assertFalse(game.isOver(true));
		
		// Enfonsem el vaixell de 2
		game.dispararVaixell(new Coordenada(4, 4), true);
		game.dispararVaixell(new Coordenada(5, 4), true);
		assertEquals(game.getRandomPlayerBoard().getVaixellsRestants(), 0);
		assertTrue(game.isOver(true));
		
		// 1r coloquem tots els vaixells al jugador aleatori
		game.placeShip(new Ship("Carrier", 5), new Coordenada(0,0), false, true);
		game.placeShip(new Ship("Battleship", 4), new Coordenada(1,1), false, true);
		game.placeShip(new Ship("Destroyer", 3), new Coordenada(2,2), false, true);
		game.placeShip(new Ship("Submarine", 3), new Coordenada(3,3), false, true);
		game.placeShip(new Ship("Patrol Boat", 2), new Coordenada(4,4), false, true);
				
		// Enfonsem el vaixell de 5
		game.dispararVaixell(new Coordenada(0, 0), false);
		game.dispararVaixell(new Coordenada(1, 0), false);
		game.dispararVaixell(new Coordenada(2, 0), false);
		game.dispararVaixell(new Coordenada(3, 0), false);
		game.dispararVaixell(new Coordenada(4, 0), false);
		assertEquals(game.getPlayerBoard().getVaixellsRestants(), 4);
		assertFalse(game.isOver(false));
				
		// Enfonsem el vaixell de 4
		game.dispararVaixell(new Coordenada(1, 1), false);
		game.dispararVaixell(new Coordenada(4, 1), false);
		game.dispararVaixell(new Coordenada(2, 1), false);
		game.dispararVaixell(new Coordenada(3, 1), false);
		assertEquals(game.getPlayerBoard().getVaixellsRestants(), 3);
		assertFalse(game.isOver(false));
				
		// Enfonsem el vaixell de 3
		game.dispararVaixell(new Coordenada(2, 2), false);
		game.dispararVaixell(new Coordenada(3, 2), false);
		game.dispararVaixell(new Coordenada(4, 2), false);
		assertEquals(game.getPlayerBoard().getVaixellsRestants(), 2);
		assertFalse(game.isOver(false));
				
		// Enfonsem el vaixell de 3
		game.dispararVaixell(new Coordenada(3, 3), false);
		game.dispararVaixell(new Coordenada(4, 3), false);
		game.dispararVaixell(new Coordenada(5, 3), false);
		assertEquals(game.getPlayerBoard().getVaixellsRestants(), 1);
		assertFalse(game.isOver(false));
				
		// Enfonsem el vaixell de 2
		game.dispararVaixell(new Coordenada(4, 4), false);
		game.dispararVaixell(new Coordenada(5, 4), false);
		assertEquals(game.getPlayerBoard().getVaixellsRestants(), 0);
		assertTrue(game.isOver(false));
	}

}