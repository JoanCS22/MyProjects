package Model;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CellTest {
	//1r tests
	Cell c, c1, c2;
	
	@BeforeEach
	void setUp()
	{
		c = new Cell();
		c1 = new Cell(new Ship("Cruiser", 4), false);
		c2 = new Cell(new Ship("Destroyer", 2), true);
	}
	
	@Test
	void testCell() {
		
		//Constructor sense parametres
		assertTrue(c.getShip() == null);
		assertFalse(c.isGuessed());
		
		
		//Constructor amb parametres
		assertFalse(c1.getShip() == null);
		assertFalse(c1.isGuessed());
		
		
		assertFalse(c2.getShip() == null);
		assertTrue(c2.isGuessed());
	}
	
	@Test
	void testSetShip()
	{
		
		assertTrue(c.getShip() == null);
		c.setShip(new Ship("Destroyer", 2));
		assertFalse(c.getShip() == null);

		assertFalse(c1.getShip() == null);
		c1.setShip(new Ship("Battleship", 4));
		assertFalse(c1.getShip() == null);
		
		assertFalse(c2.getShip() == null);
		c2.setShip(new Ship("Submarine", 3));
		assertFalse(c2.getShip() == null);
	}
	
	
	@Test
	void testSetDiscover()
	{
		//False - false
		c.setGuessed(false);
		assertFalse(c.isGuessed());
		//False - true
		c.setGuessed(true);
		assertTrue(c.isGuessed());
		//False - true
		c1.setGuessed(true);
		assertTrue(c1.isGuessed());
		//True - true
		c2.setGuessed(true);
		assertTrue(c2.isGuessed());
		//True - false
		c2.setGuessed(false);
		assertFalse(c2.isGuessed());
		
	
	}
}