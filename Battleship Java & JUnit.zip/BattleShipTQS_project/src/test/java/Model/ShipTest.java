package Model;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ShipTest {

	Ship s1, s2;
	
	@BeforeEach
	void setUp()
	{
		s1 = new Ship("Cruiser", 4);
		s2 = new Ship("Destroyer", 2);
	}
	
	@Test
	void testConstructors() {
		assertTrue(s1.getName() == "Cruiser");
		assertTrue(s1.getNHits() == 0);
		assertTrue(s1.getSize() == 4);
		
		assertTrue(s2.getName() == "Destroyer");
		assertTrue(s2.getNHits() == 0);
		assertTrue(s2.getSize() == 2);
	}
	
	@Test
	void testHitShipAndSinkIt()
	{
		assertEquals(0, s1.getNHits());
		assertFalse(s1.isSunk());
		s1.hitShip();
		assertEquals(1, s1.getNHits());
		assertFalse(s1.isSunk());
		s1.hitShip();
		assertEquals(2, s1.getNHits());
		assertFalse(s1.isSunk());
		s1.hitShip();
		assertEquals(3, s1.getNHits());
		assertFalse(s1.isSunk());
		s1.hitShip();
		assertEquals(4, s1.getNHits());
		assertTrue(s1.isSunk());
		
		assertEquals(0, s2.getNHits());
		assertFalse(s2.isSunk());
		s2.hitShip();
		assertEquals(1, s2.getNHits());
		assertFalse(s2.isSunk());
		s2.hitShip();
		assertEquals(2, s2.getNHits());
		assertTrue(s2.isSunk());
	}
}
