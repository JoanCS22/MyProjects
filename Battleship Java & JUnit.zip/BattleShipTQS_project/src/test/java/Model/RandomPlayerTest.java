package Model;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

//-Dnet.bytebuddy.experimental=true --> APlicar això a Run --> Run Configurations --> Arguments --> Copiar a VM arguments

public class RandomPlayerTest {

    private RandomPlayer randomPlayer;
    private NumGenerator mockNumGenerator;
    private Board mockBoard;
    private Ship mockShip;
    private Cell mockCell;

    @BeforeEach
    public void setUp() {
        // Inicializar los objetos Mock
        mockNumGenerator = mock(NumGenerator.class);
        mockBoard = mock(Board.class);
        mockShip = mock(Ship.class);
        mockCell = mock(Cell.class);
        
        // Crear el objeto RandomPlayer y configurar su NumGenerator
        randomPlayer = new RandomPlayer();
        randomPlayer.setNumGenerator(mockNumGenerator);
    }
    
    @Test 
    public void testGenerateCoordenadaAtac() {
    	
    	when(mockBoard.getNFiles()).thenReturn(1);
    	when(mockBoard.getNColumnes()).thenReturn(0);
    	
    	Coordenada result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	when(mockBoard.getNFiles()).thenReturn(0);
    	when(mockBoard.getNColumnes()).thenReturn(0);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	when(mockBoard.getNFiles()).thenReturn(5);
    	when(mockBoard.getNColumnes()).thenReturn(5);
    	    
    	when(mockBoard.getCasellaOcupada(0, 0)).thenReturn(true);
    	when(mockBoard.getCasella(0, 0)).thenReturn(mockCell);  
    	when(mockCell.getShip()).thenReturn(mockShip); 
    	when(mockShip.isSunk()).thenReturn(false); 
    	    
    	when(mockNumGenerator.nextInt(5)).thenReturn(0); // Fila 0
    	when(mockNumGenerator.nextInt(5)).thenReturn(1); // Columna 1

    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	    
    	assertNotNull(result);
    	assertEquals(0, result.getRow());
    	assertEquals(1, result.getCol());

    	when(mockShip.isSunk()).thenReturn(true);  
    	Coordenada result2 = randomPlayer.generateCoordenadaAtac(mockBoard);
    	assertNotNull(result2);  

    	when(mockBoard.getCasellaOcupada(0, 0)).thenReturn(false);
    	when(mockBoard.getCasellaOcupada(1, 0)).thenReturn(false);
    	when(mockBoard.getCasellaOcupada(2, 0)).thenReturn(false);
    	when(mockBoard.getCasellaOcupada(3, 0)).thenReturn(false);
    	when(mockBoard.getCasellaOcupada(4, 0)).thenReturn(false);

    	when(mockNumGenerator.nextInt(5)).thenReturn(2); 

    	Coordenada result3 = randomPlayer.generateCoordenadaAtac(mockBoard);
    	assertNotNull(result3);
    	assertEquals(2, result3.getRow());
    	assertEquals(2, result3.getCol());
    	
    	when(mockBoard.getCasellaOcupada(4, 4)).thenReturn(true);
    	when(mockBoard.getCasella(4, 4)).thenReturn(mockCell);  
    	when(mockCell.getShip()).thenReturn(mockShip); 
    	when(mockShip.isSunk()).thenReturn(false); 
    	
    	when(mockNumGenerator.nextInt(5)).thenReturn(3);
    	when(mockNumGenerator.nextInt(5)).thenReturn(4); 
    	
    	result3 = randomPlayer.generateCoordenadaAtac(mockBoard);
    	assertNotNull(result3);
    	assertEquals(3, result3.getRow());
    	assertEquals(4, result3.getCol());
    }
    
    @Test
    public void loopTesting_generarCoordAtac() {
    	//PEL BUCLE ANIUAT
    	when(mockBoard.getNFiles()).thenReturn(0);
    	when(mockBoard.getNColumnes()).thenReturn(0);
    	
    	Coordenada result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	when(mockBoard.getNFiles()).thenReturn(1);
    	when(mockBoard.getNColumnes()).thenReturn(0);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	when(mockBoard.getNFiles()).thenReturn(1);
    	when(mockBoard.getNColumnes()).thenReturn(1);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	when(mockBoard.getNFiles()).thenReturn(1);
    	when(mockBoard.getNColumnes()).thenReturn(2);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	when(mockBoard.getNFiles()).thenReturn(1);
    	when(mockBoard.getNColumnes()).thenReturn(5);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	when(mockBoard.getNFiles()).thenReturn(1);
    	when(mockBoard.getNColumnes()).thenReturn(9);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	when(mockBoard.getNFiles()).thenReturn(1);
    	when(mockBoard.getNColumnes()).thenReturn(10);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	when(mockBoard.getNFiles()).thenReturn(2);
    	when(mockBoard.getNColumnes()).thenReturn(10);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	when(mockBoard.getNFiles()).thenReturn(5);
    	when(mockBoard.getNColumnes()).thenReturn(10);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	when(mockBoard.getNFiles()).thenReturn(9);
    	when(mockBoard.getNColumnes()).thenReturn(10);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	when(mockBoard.getNFiles()).thenReturn(10);
    	when(mockBoard.getNColumnes()).thenReturn(10);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	//PER L'ÚLTIM BUCLE
    	
    	//0 elements
    	when(mockBoard.getNFiles()).thenReturn(0);
    	when(mockBoard.getNColumnes()).thenReturn(0);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	//1 element
    	when(mockBoard.getNFiles()).thenReturn(1);
    	when(mockBoard.getNColumnes()).thenReturn(1);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	//2 elements
    	when(mockBoard.getNFiles()).thenReturn(1);
    	when(mockBoard.getNColumnes()).thenReturn(2);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	//p (p < 100) elements
    	when(mockBoard.getNFiles()).thenReturn(3);
    	when(mockBoard.getNColumnes()).thenReturn(7);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	//99 elements
    	when(mockBoard.getNFiles()).thenReturn(10);
    	when(mockBoard.getNColumnes()).thenReturn(9);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    	
    	//100 elements
    	when(mockBoard.getNFiles()).thenReturn(10);
    	when(mockBoard.getNColumnes()).thenReturn(10);
    	
    	result = randomPlayer.generateCoordenadaAtac(mockBoard);
    	
    	assertNotNull(result);
    }

    @Test
    public void testCoordToPlaceShip() {
        when(mockNumGenerator.nextInt(5)).thenReturn(3); // fila 3
        when(mockNumGenerator.nextInt(5)).thenReturn(4); // columna 4
        
        Coordenada result = randomPlayer.coordToPlaceShip(mockBoard);

        assertNotNull(result);
        assertEquals(0, result.getRow());
        assertEquals(0, result.getCol());
    }


    @Test
    public void testSelectShipDirection() {
        when(mockNumGenerator.nextInt(2)).thenReturn(0); // torna true
        
        int result = randomPlayer.selectShipDirection();
        
        assertEquals(0, result);
        
        when(mockNumGenerator.nextInt(2)).thenReturn(1); // torna false
        
        result = randomPlayer.selectShipDirection();
        
        assertEquals(1, result);
    }
    
    @Test
	void testCoordenadaInteligent() {
		Coordenada c00 = new Coordenada(0, 0);
		Coordenada c09 = new Coordenada(0, 9);
		Coordenada c90 = new Coordenada(9, 0);
		Coordenada c99 = new Coordenada(9, 9);
		Coordenada c55 = new Coordenada(5, 5);
		int nFiles = 10;
		int nCols = 10;
		
		//Cantonada superior esquerra
		assertFalse(new Coordenada(-1, 0).equals(randomPlayer.getCoordenadaInteligent(c00, nFiles, nCols)));
		assertFalse(new Coordenada(1, 0).equals(randomPlayer.getCoordenadaInteligent(c00, nFiles, nCols)));
		assertFalse(new Coordenada(0, -1).equals(randomPlayer.getCoordenadaInteligent(c00, nFiles, nCols)));
		assertTrue(new Coordenada(0, 1).equals(randomPlayer.getCoordenadaInteligent(c00, nFiles, nCols)));
		
		//Cantonada superior dreta
		assertFalse(new Coordenada(-1, 9).equals(randomPlayer.getCoordenadaInteligent(c09, nFiles, nCols)));
		assertFalse(new Coordenada(0, 8).equals(randomPlayer.getCoordenadaInteligent(c09, nFiles, nCols)));
		assertFalse(new Coordenada(0, 10).equals(randomPlayer.getCoordenadaInteligent(c09, nFiles, nCols)));
		assertTrue(new Coordenada(1, 9).equals(randomPlayer.getCoordenadaInteligent(c09, nFiles, nCols)));
		
		//Cantonada inferior esquerra
		assertFalse(new Coordenada(9, -1).equals(randomPlayer.getCoordenadaInteligent(c90, nFiles, nCols)));
		assertFalse(new Coordenada(9, 1).equals(randomPlayer.getCoordenadaInteligent(c90, nFiles, nCols)));
		assertFalse(new Coordenada(10, 0).equals(randomPlayer.getCoordenadaInteligent(c90, nFiles, nCols)));
		assertTrue(new Coordenada(8, 0).equals(randomPlayer.getCoordenadaInteligent(c90, nFiles, nCols)));
		
		//Cantonada inferior dreta
		assertFalse(new Coordenada(9, 10).equals(randomPlayer.getCoordenadaInteligent(c99, nFiles, nCols)));
		assertFalse(new Coordenada(9, 8).equals(randomPlayer.getCoordenadaInteligent(c99, nFiles, nCols)));
		assertFalse(new Coordenada(10, 9).equals(randomPlayer.getCoordenadaInteligent(c99, nFiles, nCols)));
		assertTrue(new Coordenada(8, 9).equals(randomPlayer.getCoordenadaInteligent(c99, nFiles, nCols)));
		
		//Coordenada al mig del tauler
		assertFalse(new Coordenada(5, 4).equals(randomPlayer.getCoordenadaInteligent(c55, nFiles, nCols)));
		assertFalse(new Coordenada(5, 6).equals(randomPlayer.getCoordenadaInteligent(c55, nFiles, nCols)));
		assertFalse(new Coordenada(6, 5).equals(randomPlayer.getCoordenadaInteligent(c55, nFiles, nCols)));
		assertTrue(new Coordenada(4, 5).equals(randomPlayer.getCoordenadaInteligent(c55, nFiles, nCols)));
		
		//Provar últim cas
		Coordenada c01 = new Coordenada(0, 1);
		assertFalse(new Coordenada(-1, 1).equals(randomPlayer.getCoordenadaInteligent(c01, 1, 2)));
		assertFalse(new Coordenada(1, 1).equals(randomPlayer.getCoordenadaInteligent(c01, 1, 2)));
		assertFalse(new Coordenada(0, 2).equals(randomPlayer.getCoordenadaInteligent(c01, 1, 2)));
		assertTrue(new Coordenada(0, 0).equals(randomPlayer.getCoordenadaInteligent(c01, 1, 2)));
	}
}
