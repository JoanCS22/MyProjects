package Model;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CoordenadaTest {

	@Test
	void testConstructor() {
		//No provem files o columnes negatives pels asserts del codi desenvolupat
		//Prova meitat
		Coordenada cR = new Coordenada(3,7);
		assertEquals(3, cR.getRow());
		assertEquals(7, cR.getCol());
		
		//Provar límit superior
		Coordenada c1 = new Coordenada(1,1);
		assertEquals(1, c1.getRow());
		assertEquals(1, c1.getCol());
		
		//Provar límit inferior
		Coordenada c10 = new Coordenada(10,10);
		assertNotEquals(0, c10.getCol());
		assertNotEquals(0, c10.getRow());
		assertNotEquals(9, c10.getCol());
		assertNotEquals(9, c10.getRow());
		assertEquals(10, c10.getRow());
		assertEquals(10, c10.getCol());
		assertNotEquals(11, c10.getCol());
		assertNotEquals(11, c10.getRow());
		assertNotEquals(1200, c10.getCol());
		assertNotEquals(1200, c10.getRow());
	}
	
	@Test
	void testEquals()
	{
		Coordenada c1 = new Coordenada(2,5);
		Coordenada c2 = new Coordenada(9, 3);
		Coordenada c3 = new Coordenada(9, 3);
		Coordenada c4 = new Coordenada(2, 7);
		
		assertFalse(c1.equals(c3));
		assertFalse(c3.equals(c1));
		
		assertTrue(c2.equals(c3));
		assertTrue(c3.equals(c2));
		
		assertTrue(c1.equals(c1));
		assertFalse(c1.equals(c4));
	}
}
